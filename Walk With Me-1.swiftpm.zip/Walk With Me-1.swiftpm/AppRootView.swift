import SwiftUI

struct AppRootView: View {
    @EnvironmentObject private var store: WalkStore
    @EnvironmentObject private var session: WalkSessionViewModel

    @State private var path: [Route] = []
    @State private var recordingSessionID: UUID = UUID()
    @State private var simulateSessionID: UUID = UUID()

    enum Route: Hashable {
        case recording
        case simulate
        case result
        case memoryWall
        case artworkDetail(walkID: String, fromResult: Bool)
    }

    var body: some View {
        NavigationStack(path: $path) {
            HomeView {
                session.resetToIdle()
                recordingSessionID = UUID()
                var transaction = Transaction(animation: .none)
                transaction.disablesAnimations = true
                withTransaction(transaction) {
                    path.append(.recording)
                }
            } startSimulation: {
                session.resetToIdle()
                simulateSessionID = UUID()
                var transaction = Transaction(animation: .none)
                transaction.disablesAnimations = true
                withTransaction(transaction) {
                    path.append(.simulate)
                }
            } openHistory: {
                path.append(.memoryWall)
            }
            .navigationDestination(for: Route.self) { route in
                switch route {
                case .recording:
                    WalkRecordingView {
                        session.startWalk()
                    } endWalk: {
                        session.endWalk()
                        path.append(.result)
                    }
                    .id(recordingSessionID)
                    .task {
                        // Ensure at least one authorization prompt attempt on entry
                        // (actual prompt is handled in WalkLocationManager)
                    }

                case .simulate:
                    SimulateWalkView {
                        path = []
                    } onEnd: { artwork, duration in
                        session.presentSimulatedResult(artwork: artwork, duration: duration)
                        path.append(.result)
                    }
                    .id(simulateSessionID)

                case .result:
                    WalkResultContainerView { walkID in
                        path.append(.artworkDetail(walkID: walkID, fromResult: true))
                    } onWalkAgain: {
                        let styleType = session.currentWalk?.styleType
                        session.resetToIdle()
                        if styleType == "simulate" {
                            simulateSessionID = UUID()
                            path = [.simulate]
                        } else {
                            recordingSessionID = UUID()
                            path = [.recording]
                        }
                    } onBackToHome: {
                        session.resetToIdle()
                        path = []
                    }

                case .memoryWall:
                    MemoryWallView { walk in
                        path.append(.artworkDetail(walkID: walk.id, fromResult: false))
                    }

                case let .artworkDetail(walkID, fromResult):
                    WalkArtworkDetailView(
                        walkID: walkID,
                        showToGalleryButton: fromResult,
                        backButtonTitle: fromResult ? "Home" : nil,
                        onBack: {
                            session.resetToIdle()
                            path = []
                        },
                        onToGallery: {
                            path = [.memoryWall]
                        },
                        onDeleted: {
                            if fromResult {
                                session.resetToIdle()
                                path = []
                            } else if !path.isEmpty {
                                path.removeLast()
                            }
                        }
                    )
                }
            }
        }
        .tint(AppTheme.actionPrimary)
    }
}

private struct WalkResultContainerView: View {
    @EnvironmentObject private var session: WalkSessionViewModel

    let onSaved: (String) -> Void
    let onWalkAgain: () -> Void
    let onBackToHome: () -> Void

    @State private var isProcessing: Bool = false

    var body: some View {
        ZStack {
            if session.lifecycle == .processing {
                VStack(spacing: 14) {
                    ProgressView()
                        .tint(AppTheme.actionPrimary)
                        .accessibilityLabel("Generating artwork")
                    Text("Generating artwork…")
                        .foregroundStyle(AppTheme.textSecondary)
                }
                .transition(.opacity)
            }

            WalkResultView(completeSave: onSaved, walkAgain: onWalkAgain, backToHome: onBackToHome)
                .opacity(session.lifecycle == .processing ? 0 : 1)
        }
        .background(AppTheme.pageBackground.ignoresSafeArea())
        .task {
            guard session.lifecycle == .processing else { return }
            guard !isProcessing else { return }
            isProcessing = true

            let coords = session.currentWalk?.pathCoordinates ?? []
            let artwork = await Task.detached(priority: .userInitiated) {
                PathProcessing.generateArtworkPoints(from: coords)
            }.value

            session.finishProcessing(artwork: artwork)
        }
    }
}
