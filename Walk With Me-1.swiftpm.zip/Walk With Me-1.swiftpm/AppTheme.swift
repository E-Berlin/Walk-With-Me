import SwiftUI

enum AppTheme {
    static let homeBackground = Color(hex: "#855b50") ?? Color(.sRGB, red: 0.52, green: 0.36, blue: 0.31, opacity: 1)
    static let pageBackground = Color(hex: "#ecce95") ?? Color(.sRGB, red: 0.93, green: 0.81, blue: 0.58, opacity: 1)

    static let cardBackground = Color(hex: "#f5e7c8") ?? Color(.sRGB, red: 0.96, green: 0.91, blue: 0.78, opacity: 1)
    static let canvasBackground = Color(hex: "#f2dfb8") ?? Color(.sRGB, red: 0.95, green: 0.88, blue: 0.72, opacity: 1)
    static let chipBackground = Color(hex: "#e4c98f") ?? Color(.sRGB, red: 0.89, green: 0.79, blue: 0.56, opacity: 1)
    static let surfaceStroke = Color(hex: "#c9a56d") ?? Color(.sRGB, red: 0.79, green: 0.65, blue: 0.43, opacity: 1)

    static let textPrimary = Color(hex: "#3f2e24") ?? Color(.sRGB, red: 0.25, green: 0.18, blue: 0.14, opacity: 1)
    static let textSecondary = Color(hex: "#705443") ?? Color(.sRGB, red: 0.44, green: 0.33, blue: 0.26, opacity: 1)

    static let actionPrimary = Color(hex: "#3f6b58") ?? Color(.sRGB, red: 0.25, green: 0.42, blue: 0.35, opacity: 1)
    static let actionSecondary = Color(hex: "#628a73") ?? Color(.sRGB, red: 0.38, green: 0.54, blue: 0.45, opacity: 1)
    static let destructive = Color(hex: "#a34f3f") ?? Color(.sRGB, red: 0.64, green: 0.31, blue: 0.25, opacity: 1)

    static let recordingActive = Color(hex: "#8f3b34") ?? Color(.sRGB, red: 0.56, green: 0.23, blue: 0.2, opacity: 1)
    static let recordingPaused = Color(hex: "#8a6a3f") ?? Color(.sRGB, red: 0.54, green: 0.42, blue: 0.25, opacity: 1)
    static let mapPath = Color(hex: "#3f6b58") ?? Color(.sRGB, red: 0.25, green: 0.42, blue: 0.35, opacity: 1)

    static let moodPaletteNames: [String] = [
        "Sunny Yellow",
        "Energetic Red",
        "Fresh Green",
        "Ocean Blue",
        "Calm Teal",
        "Warm Orange",
        "Grounded Brown",
        "Quiet Slate"
    ]

    static let moodPaletteHex: [String] = [
        "#F6C945",
        "#E4572E",
        "#4CAF50",
        "#2E86DE",
        "#2A9D8F",
        "#F4A261",
        "#8D6E63",
        "#6C7A89"
    ]

    static let moodPalette: [Color] = moodPaletteHex.map { hex in
        Color(hex: hex) ?? actionPrimary
    }
}
