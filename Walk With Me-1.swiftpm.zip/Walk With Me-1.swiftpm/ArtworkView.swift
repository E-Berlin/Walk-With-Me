import SwiftUI

struct ArtworkView: View {
    let points: [NormalizedPoint]
    let tint: Color
    var lineWidth: CGFloat = 3
    var enforcedAspectRatio: CGFloat? = 1

    @ViewBuilder
    var body: some View {
        if let enforcedAspectRatio {
            artworkContent
                .aspectRatio(enforcedAspectRatio, contentMode: .fit)
        } else {
            artworkContent
        }
    }

    private var artworkContent: some View {
        GeometryReader { proxy in
            let rect = proxy.frame(in: .local)
            let normalizedPoints = points.map(\NormalizedPoint.cgPoint)

            Canvas { context, size in
                let mapped = PathProcessing.fitNormalizedPointsToRect(normalizedPoints, in: rect, padding: 12)
                guard mapped.count >= 2 else { return }

                var path = Path()

                path.move(to: mapped[0])
                path.addLines(Array(mapped.dropFirst()))

                context.stroke(
                    path,
                    with: .color(tint),
                    style: StrokeStyle(lineWidth: lineWidth, lineCap: .round, lineJoin: .round)
                )
            }
            .drawingGroup()
            .background(AppTheme.canvasBackground, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .strokeBorder(AppTheme.surfaceStroke.opacity(0.45), lineWidth: 1)
            }
            .accessibilityLabel("Walk artwork preview")
        }
    }
}
