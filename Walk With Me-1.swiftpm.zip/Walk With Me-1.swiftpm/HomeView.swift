import AVKit
import SwiftUI
import UIKit

struct HomeView: View {
    @EnvironmentObject private var store: WalkStore

    @State private var animateIntro: Bool = false
    @State private var showLastWalkPreview: Bool = false
    @State private var revealProgress: CGFloat = 0
    @State private var previewOpacityProgress: CGFloat = 0
    @State private var revealAnimationToken: UUID = UUID()
    @State private var isTransitioningAway: Bool = false
    @State private var homeExitProgress: CGFloat = 0
    @State private var backgroundFadeProgress: CGFloat = 0
    @State private var simulationButtonExitProgress: CGFloat = 0
    @State private var startTransitionToken: UUID = UUID()
    @State private var shouldRestoreExpandedLastWalkOnReturn: Bool = false
    @State private var infoPanelCollapseProgress: CGFloat = 0
    @State private var shouldRestoreInfoPanelExpandedOnReturn: Bool = false
    @State private var startWalkFloatPhase: Bool = false
    @State private var simulationCTAHighlightPhase: Bool = false

    let startWalk: () -> Void
    let startSimulation: () -> Void
    let openHistory: () -> Void

    private let contentPadding: CGFloat = 20
    private let cardInnerPadding: CGFloat = 14
    private let cardVerticalSpacing: CGFloat = 10
    private let secondaryButtonHeight: CGFloat = 48
    private var collapsedLastWalkCardHeight: CGFloat {
        (cardInnerPadding * 2) + (secondaryButtonHeight * 2) + cardVerticalSpacing
    }

    private func beginNavigationTransition(performNavigation: @escaping () -> Void) {
        guard !isTransitioningAway else { return }

        let token = UUID()
        startTransitionToken = token
        isTransitioningAway = true

        let shouldCollapseLastWalkFirst = showLastWalkPreview || revealProgress > 0.001
        shouldRestoreExpandedLastWalkOnReturn = shouldCollapseLastWalkFirst
        shouldRestoreInfoPanelExpandedOnReturn = true

        withAnimation(.easeOut(duration: 0.18)) {
            infoPanelCollapseProgress = 1
            simulationButtonExitProgress = 1
        }

        let preExitDelay: TimeInterval

        if shouldCollapseLastWalkFirst {
            showLastWalkPreview = false

            withAnimation(.easeOut(duration: 0.16)) {
                previewOpacityProgress = 0
            }

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.16) {
                guard startTransitionToken == token else { return }
                withAnimation(.easeInOut(duration: 0.24)) {
                    revealProgress = 0
                }
            }

            preExitDelay = 0.42
        } else {
            preExitDelay = 0.18
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + preExitDelay) {
            guard startTransitionToken == token else { return }

            withAnimation(.easeInOut(duration: 0.34)) {
                homeExitProgress = 1
            }

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                guard startTransitionToken == token else { return }
                withAnimation(.easeInOut(duration: 0.3)) {
                    backgroundFadeProgress = 1
                }
            }

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.58) {
                guard startTransitionToken == token else { return }
                performNavigation()
            }
        }
    }

    private func beginStartWalkTransition() {
        beginNavigationTransition {
            startWalk()
        }
    }

    private func beginStartSimulationTransition() {
        beginNavigationTransition {
            startSimulation()
        }
    }

    private var shouldHighlightSimulationCTA: Bool {
        !isTransitioningAway && simulationButtonExitProgress <= 0.001
    }

    private func setSimulationCTAHighlight(_ enabled: Bool) {
        if enabled {
            simulationCTAHighlightPhase = false
            withAnimation(.easeInOut(duration: 1.05).repeatForever(autoreverses: true)) {
                simulationCTAHighlightPhase = true
            }
        } else {
            simulationCTAHighlightPhase = false
        }
    }

    private var shouldFloatStartWalk: Bool {
        !showLastWalkPreview && revealProgress <= 0.001 && !isTransitioningAway
    }

    private func setStartWalkFloating(_ enabled: Bool) {
        if enabled {
            startWalkFloatPhase = false
            withAnimation(.easeInOut(duration: 1.2).repeatForever(autoreverses: true)) {
                startWalkFloatPhase = true
            }
        } else {
            startWalkFloatPhase = false
        }
    }

    var body: some View {
        GeometryReader { geometry in
            let topExitOffset = -geometry.size.height * 0.42 * homeExitProgress
            let bottomExitOffset = geometry.size.height * 0.42 * homeExitProgress
            let infoPanelProgress = max(revealProgress, infoPanelCollapseProgress)
            let topCardUpwardNudge: CGFloat = 12
            let simulationButtonExitOffset = geometry.size.width * 0.86 * simulationButtonExitProgress

            ZStack {
                HomeBackgroundView(transitionProgress: backgroundFadeProgress, revealProgress: revealProgress)
                    .ignoresSafeArea()

                ScrollView {
                    let previewTargetHeight = min(max(geometry.size.width * 0.86, 250), 420)
                    let expandedLastWalkCardHeight = collapsedLastWalkCardHeight + previewTargetHeight + cardVerticalSpacing
                    let expansionHeight = (expandedLastWalkCardHeight - collapsedLastWalkCardHeight) * revealProgress

                    VStack(alignment: .center, spacing: 16) {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack(alignment: .firstTextBaseline, spacing: 8) {
                                Image(systemName: "pawprint.fill")
                                    .font(.title3.weight(.semibold))
                                    .foregroundStyle(AppTheme.textPrimary)
                                    .accessibilityHidden(true)

                                Text("Walk With Me")
                                    .font(.largeTitle)
                                    .fontWeight(.semibold)
                                    .foregroundStyle(AppTheme.textPrimary)
                            }

                            Text("Ready for today’s walk?")
                                .font(.title3.weight(.semibold))
                                .foregroundStyle(AppTheme.textSecondary)

                            Text("Turn every dog walk into mood-tinted art memories, capturing companionship through GPS paths that grow into a shared life portrait.")
                                .font(.body)
                                .foregroundStyle(AppTheme.textSecondary)
                                .lineSpacing(3)
                                .fixedSize(horizontal: false, vertical: true)
                                .mask(alignment: .top) {
                                    Rectangle()
                                        .frame(height: max(0, 120 * (1 - infoPanelProgress)))
                                }
                                .opacity(Double(1 - infoPanelProgress))
                                .offset(y: -12 * infoPanelProgress)
                        }
                        .padding(.horizontal, 14)
                        .padding(.vertical, 14)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(AppTheme.cardBackground)
                                .opacity(0.86)
                        }
                        .overlay {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .strokeBorder(AppTheme.surfaceStroke, lineWidth: 1)
                                .opacity(0.35)
                        }
                        .mask(alignment: .top) {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .frame(height: max(98, 204 - (106 * infoPanelProgress)))
                        }
                        .offset(y: topExitOffset - topCardUpwardNudge)
                        .opacity(Double(1 - (0.18 * homeExitProgress)))

                        HStack {
                            Spacer()

                            Button {
                                beginStartSimulationTransition()
                            } label: {
                                Text("Can’t go out? Take a mindful dog walk →")
                                    .font(.callout.weight(.semibold))
                                    .lineLimit(nil)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: 152, alignment: .leading)
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundStyle(Color(hex: "#3E2B1F") ?? AppTheme.textPrimary)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 12)
                                    .background(
                                        LinearGradient(
                                            colors: [
                                                (Color(hex: "#F8D37A") ?? AppTheme.cardBackground).opacity(0.96),
                                                (Color(hex: "#F4B96A") ?? AppTheme.cardBackground).opacity(0.94)
                                            ],
                                            startPoint: .topLeading,
                                            endPoint: .bottomTrailing
                                        ),
                                        in: RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    )
                                    .overlay {
                                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                                            .strokeBorder((Color(hex: "#D38A45") ?? AppTheme.surfaceStroke).opacity(0.8), lineWidth: 1.2)
                                    }
                                    .shadow(
                                        color: (Color(hex: "#F0AE55") ?? AppTheme.actionPrimary)
                                            .opacity(shouldHighlightSimulationCTA ? (simulationCTAHighlightPhase ? 0.42 : 0.2) : 0.18),
                                        radius: shouldHighlightSimulationCTA ? (simulationCTAHighlightPhase ? 14 : 6) : 6,
                                        x: 0,
                                        y: 4
                                    )
                            }
                            .scaleEffect(shouldHighlightSimulationCTA ? (simulationCTAHighlightPhase ? 1.035 : 1) : 1)
                            .offset(x: simulationButtonExitOffset)
                            .frame(width: 190, alignment: .trailing)
                            .buttonStyle(PressScaleButtonStyle())
                            .accessibilityLabel("Simulation mode")
                        }
                        .offset(y: topExitOffset - topCardUpwardNudge)
                        .opacity(Double(1 - (0.18 * homeExitProgress)))

                        Spacer(minLength: max(geometry.size.height * 0.18, 120))

                        Button {
                            beginStartWalkTransition()
                        } label: {
                            Label("Start Walk", systemImage: "location.fill")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .frame(minHeight: 52)
                                .contentShape(Rectangle())
                        }
                        .offset(y: -expansionHeight + bottomExitOffset + (shouldFloatStartWalk ? (startWalkFloatPhase ? -7 : 0) : 0))
                        .buttonStyle(.borderedProminent)
                        .tint(AppTheme.actionPrimary)
                        .accessibilityLabel("Start walk")

                        Color.clear
                            .frame(height: collapsedLastWalkCardHeight)
                            .overlay(alignment: .bottom) {
                                VStack(alignment: .leading, spacing: cardVerticalSpacing) {
                                    secondaryCardButton(
                                        title: showLastWalkPreview ? "Hide Last Walk" : "Show Last Walk",
                                        systemImage: showLastWalkPreview ? "eye.slash" : "photo"
                                    ) {
                                        toggleLastWalkPreview()
                                    }

                                    if revealProgress > 0.001 {
                                        Group {
                                            if let last = store.walks.first,
                                               let points = last.artworkPoints,
                                               !points.isEmpty {
                                                let tint = (last.moodColorHex.flatMap { Color(hex: $0) }) ?? AppTheme.actionPrimary
                                                ArtworkView(points: points, tint: tint, lineWidth: 3)
                                                    .frame(maxWidth: .infinity)
                                            } else {
                                                EmptyStateView(
                                                    title: "No walks yet",
                                                    systemImage: "figure.walk",
                                                    message: "Start a walk to create your first memory."
                                                )
                                                .frame(maxWidth: .infinity)
                                                .frame(height: previewTargetHeight)
                                                .accessibilityLabel("No walks yet")
                                            }
                                        }
                                        .frame(height: previewTargetHeight * revealProgress)
                                        .clipped()
                                        .opacity(Double(max(previewOpacityProgress, 0.001)))
                                        .offset(y: (1 - previewOpacityProgress) * 20)
                                    }

                                    secondaryCardButton(
                                        title: store.walks.count == 1 ? "View Walk Memory" : "View Walk Memories",
                                        systemImage: "square.grid.2x2"
                                    ) {
                                        openHistory()
                                    }
                                    .accessibilityLabel(store.walks.count == 1 ? "View walk memory" : "View walk memories")
                                }
                                .padding(cardInnerPadding)
                                .frame(maxWidth: .infinity)
                                .frame(height: collapsedLastWalkCardHeight + expansionHeight, alignment: .bottom)
                                .background {
                                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                                        .fill(AppTheme.cardBackground)
                                        .opacity(0.86)
                                }
                                .overlay {
                                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                                        .strokeBorder(AppTheme.surfaceStroke, lineWidth: 1)
                                        .opacity(0.35)
                                }
                            }
                        .offset(y: bottomExitOffset)
                        .frame(maxWidth: .infinity)
                    }
                    .padding(contentPadding)
                    .frame(maxWidth: .infinity)
                    .frame(minHeight: geometry.size.height, alignment: .top)
                    .offset(y: animateIntro ? 0 : 8)
                    .opacity(animateIntro ? 1 : 0.9)
                    .animation(.easeOut(duration: 0.45), value: animateIntro)
                }
                .allowsHitTesting(!isTransitioningAway)
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .onAppear {
            animateIntro = true
            isTransitioningAway = false
            homeExitProgress = 0
            backgroundFadeProgress = 0
            simulationButtonExitProgress = 0
            if shouldRestoreExpandedLastWalkOnReturn {
                showLastWalkPreview = true
                revealProgress = 1
                previewOpacityProgress = 1
                shouldRestoreExpandedLastWalkOnReturn = false
            } else if showLastWalkPreview {
                revealProgress = 1
                previewOpacityProgress = 1
            }

            let keepInfoPanelCollapsed = showLastWalkPreview || revealProgress > 0.001
            if shouldRestoreInfoPanelExpandedOnReturn {
                infoPanelCollapseProgress = keepInfoPanelCollapsed ? 1 : 0
                shouldRestoreInfoPanelExpandedOnReturn = false
            } else {
                infoPanelCollapseProgress = keepInfoPanelCollapsed ? 1 : 0
            }

            simulationButtonExitProgress = keepInfoPanelCollapsed ? 1 : 0
            setStartWalkFloating(shouldFloatStartWalk)
            setSimulationCTAHighlight(shouldHighlightSimulationCTA)
        }
        .onChange(of: shouldFloatStartWalk) { shouldFloat in
            setStartWalkFloating(shouldFloat)
        }
        .onChange(of: shouldHighlightSimulationCTA) { shouldHighlight in
            setSimulationCTAHighlight(shouldHighlight)
        }
    }

    private func toggleLastWalkPreview() {
        let token = UUID()
        revealAnimationToken = token

        if showLastWalkPreview {
            showLastWalkPreview = false
            withAnimation(.easeOut(duration: 0.18)) {
                previewOpacityProgress = 0
            }

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) {
                guard revealAnimationToken == token, !showLastWalkPreview else { return }
                withAnimation(.spring(response: 0.34, dampingFraction: 0.84)) {
                    revealProgress = 0
                    infoPanelCollapseProgress = 0
                }

                DispatchQueue.main.asyncAfter(deadline: .now() + 0.24) {
                    guard revealAnimationToken == token, !showLastWalkPreview else { return }
                    withAnimation(.easeOut(duration: 0.18)) {
                        simulationButtonExitProgress = 0
                    }
                }
            }
        } else {
            showLastWalkPreview = true
            previewOpacityProgress = 0

            withAnimation(.spring(response: 0.34, dampingFraction: 0.84)) {
                revealProgress = 1
                simulationButtonExitProgress = 1
            }

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.22) {
                guard revealAnimationToken == token, showLastWalkPreview else { return }
                withAnimation(.easeOut(duration: 0.2)) {
                    previewOpacityProgress = 1
                }
            }
        }
    }

    @ViewBuilder
    private func secondaryCardButton(title: String, systemImage: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: systemImage)
                .font(.headline)
                .frame(maxWidth: .infinity)
                .frame(height: secondaryButtonHeight)
                .contentShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
        .frame(maxWidth: .infinity)
        .contentShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .foregroundStyle(AppTheme.textPrimary)
        .background {
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(AppTheme.cardBackground)
                .opacity(0.92)
        }
        .buttonStyle(PressScaleButtonStyle())
    }
}

private struct HomeBackgroundView: View {
    let transitionProgress: CGFloat
    let revealProgress: CGFloat

    private let topHalfColor = Color(hex: "#ecce95") ?? AppTheme.pageBackground
    private let bottomHalfColor = Color(hex: "#855b50") ?? AppTheme.homeBackground
    private let fallbackVideoAssetName = "HomeLoopVideo"

    @State private var videoSource: VideoSource = .assetVideo

    private enum VideoSource {
        case assetVideo
        case fallbackImage
    }

    var body: some View {
        GeometryReader { geometry in
            let upwardShift = -geometry.size.height / 14
            let extraLiftOnPreview = geometry.size.height * 0.08 * revealProgress
            let downwardNudge: CGFloat = 18

            ZStack {
                LinearGradient(
                    stops: [
                        .init(color: topHalfColor, location: 0),
                        .init(color: topHalfColor, location: 0.5),
                        .init(color: bottomHalfColor, location: 0.5),
                        .init(color: bottomHalfColor, location: 1)
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )

                Group {
                    switch videoSource {
                    case .assetVideo:
                        if let url = assetVideoURL() {
                            LoopingVideoBackground(url: url) {
                                videoSource = .fallbackImage
                            }
                        } else {
                            Color.clear
                                .task {
                                    videoSource = .fallbackImage
                                }
                        }

                    case .fallbackImage:
                        fallbackAssetImageView
                    }
                }
                .offset(y: upwardShift - extraLiftOnPreview + downwardNudge)
                .scaleEffect(1.08)
                .frame(width: geometry.size.width, height: geometry.size.height)

                AppTheme.pageBackground
                    .opacity(Double(transitionProgress))
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
        }
    }

    private func assetVideoURL() -> URL? {
        guard let asset = NSDataAsset(name: fallbackVideoAssetName) else { return nil }

        let tempURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("\(fallbackVideoAssetName).mp4")

        do {
            let needsWrite: Bool
            if let attrs = try? FileManager.default.attributesOfItem(atPath: tempURL.path),
               let size = attrs[.size] as? NSNumber {
                needsWrite = size.intValue != asset.data.count
            } else {
                needsWrite = true
            }

            if needsWrite {
                try asset.data.write(to: tempURL, options: [.atomic])
            }
            return tempURL
        } catch {
            return nil
        }
    }

    @ViewBuilder
    private var fallbackAssetImageView: some View {
        if UIImage(named: "HomeFallback") != nil {
            Image("HomeFallback")
                .resizable()
                .scaledToFill()
        } else {
            AnimatedHomeBackground()
        }
    }
}

private struct AnimatedHomeBackground: View {
    @State private var animate = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    AppTheme.homeBackground.opacity(0.96),
                    (Color(hex: "#9a6f62") ?? AppTheme.homeBackground).opacity(0.82),
                    (Color(hex: "#6a463f") ?? AppTheme.homeBackground).opacity(0.9)
                ],
                startPoint: animate ? .topLeading : .bottomLeading,
                endPoint: animate ? .bottomTrailing : .topTrailing
            )

            Circle()
                .fill(Color.white.opacity(0.18))
                .frame(width: 260, height: 260)
                .blur(radius: 12)
                .offset(x: animate ? 110 : -80, y: animate ? -180 : -120)

            Circle()
                .fill(Color.white.opacity(0.14))
                .frame(width: 220, height: 220)
                .blur(radius: 10)
                .offset(x: animate ? -120 : 120, y: animate ? 200 : 120)
        }
        .animation(.easeInOut(duration: 8).repeatForever(autoreverses: true), value: animate)
        .onAppear {
            animate = true
        }
    }
}

private struct LoopingVideoBackground: UIViewRepresentable {
    let url: URL
    let onPlaybackFailure: () -> Void

    func makeUIView(context: Context) -> PlayerView {
        let view = PlayerView()
        let item = AVPlayerItem(url: url)
        let player = AVPlayer(playerItem: item)
        player.isMuted = true
        player.actionAtItemEnd = .none

        let coordinator = context.coordinator
        coordinator.player = player
        coordinator.endObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: item,
            queue: .main
        ) { _ in
            player.seek(to: .zero)
            player.play()
        }

        coordinator.failureObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemFailedToPlayToEndTime,
            object: item,
            queue: .main
        ) { [weak coordinator] _ in
            coordinator?.reportFailureIfNeeded()
        }

        player.play()

        view.playerLayer.player = player
        return view
    }

    func updateUIView(_ uiView: PlayerView, context: Context) {
        uiView.playerLayer.videoGravity = .resizeAspect
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(onPlaybackFailure: onPlaybackFailure)
    }

    static func dismantleUIView(_ uiView: PlayerView, coordinator: Coordinator) {
        coordinator.player?.pause()
        if let observer = coordinator.endObserver {
            NotificationCenter.default.removeObserver(observer)
        }
        if let observer = coordinator.failureObserver {
            NotificationCenter.default.removeObserver(observer)
        }
    }

    final class Coordinator: @unchecked Sendable {
        var player: AVPlayer?
        var endObserver: NSObjectProtocol?
        var failureObserver: NSObjectProtocol?
        private var didReportFailure = false

        func reportFailureIfNeeded() {
            guard !didReportFailure else { return }
            didReportFailure = true
            onPlaybackFailure()
        }

        private let onPlaybackFailure: () -> Void

        init(onPlaybackFailure: @escaping () -> Void) {
            self.onPlaybackFailure = onPlaybackFailure
        }
    }
}

private final class PlayerView: UIView {
    override static var layerClass: AnyClass { AVPlayerLayer.self }
    var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
}
