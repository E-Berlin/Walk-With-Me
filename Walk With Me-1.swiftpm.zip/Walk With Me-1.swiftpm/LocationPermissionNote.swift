import SwiftUI
import UIKit

struct LocationPermissionNote: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Location permission needed", systemImage: "location")
                .font(.headline)
                .foregroundStyle(AppTheme.textPrimary)
                .accessibilityLabel("Location permission needed")

            Text("To record your walk path, enable Location access for this app in Settings.")
                .foregroundStyle(AppTheme.textSecondary)
                .font(.body)

            Button {
                guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
                UIApplication.shared.open(url)
            } label: {
                Label("Open Settings", systemImage: "gear")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.vertical, 8)
            }
            .buttonStyle(.bordered)
            .tint(AppTheme.actionPrimary)
            .accessibilityLabel("Open Settings")
        }
        .padding(14)
        .background(AppTheme.cardBackground, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .strokeBorder(AppTheme.surfaceStroke.opacity(0.5), lineWidth: 1)
        }
    }
}
