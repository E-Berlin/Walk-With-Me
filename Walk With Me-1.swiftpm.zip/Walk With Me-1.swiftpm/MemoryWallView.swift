import SwiftUI

struct MemoryWallView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var store: WalkStore
    let openWalk: (WalkRecord) -> Void

    @State private var range: TimeRange = .days7
    @State private var renameTarget: WalkRecord?
    @State private var renameInput: String = ""
    @State private var deleteTarget: WalkRecord?
    @State private var visibleCount: Int = 24
    @State private var animatedWalkIDs: Set<String> = []
    @State private var gridAnimationSeed: UUID = UUID()

    private let pageSize: Int = 24

    init(openWalk: @escaping (WalkRecord) -> Void = { _ in }) {
        self.openWalk = openWalk
    }

    private enum TimeRange: String, CaseIterable, Identifiable {
        case days7 = "7D"
        case days30 = "30D"
        case days365 = "365D"
        case all = "All"

        var id: String { rawValue }

        var days: Int? {
            switch self {
            case .days7: return 7
            case .days30: return 30
            case .days365: return 365
            case .all: return nil
            }
        }
    }

    var body: some View {
        VStack(spacing: 12) {
            Picker("Time range", selection: $range) {
                ForEach(TimeRange.allCases) { r in
                    Text(r.rawValue).tag(r)
                }
            }
            .font(.headline)
            .pickerStyle(.segmented)
            .tint(AppTheme.actionPrimary)
            .scaleEffect(x: 1, y: 1.15, anchor: .center)
            .padding(.vertical, 4)
            .frame(maxWidth: .infinity)
            .accessibilityLabel("Time range")

            ScrollView {
                let filtered = filteredWalks
                let displayed = Array(filtered.prefix(visibleCount))
                let didFinishDisplayingCurrentBatch = !displayed.isEmpty && displayed.allSatisfy { animatedWalkIDs.contains($0.id) }

                if filtered.isEmpty {
                    EmptyStateView(
                        title: "No walks",
                        systemImage: "photo.on.rectangle.angled",
                        message: "Your memories will appear here."
                    )
                        .padding(.top, 40)
                        .accessibilityLabel("No walks")
                } else {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 150, maximum: 220), spacing: 12)], spacing: 12) {
                        ForEach(Array(displayed.enumerated()), id: \.element.id) { index, walk in
                            Button {
                                openWalk(walk)
                            } label: {
                                MemoryCell(walk: walk, title: store.displayName(for: walk))
                            }
                            .buttonStyle(PressScaleButtonStyle())
                            .contextMenu {
                                Button {
                                    renameTarget = walk
                                    renameInput = store.displayName(for: walk)
                                } label: {
                                    Label("Rename", systemImage: "pencil")
                                }

                                ShareLink(item: shareText(for: walk)) {
                                    Label("Share", systemImage: "square.and.arrow.up")
                                }

                                Button(role: .destructive) {
                                    deleteTarget = walk
                                } label: {
                                    Label("Delete", systemImage: "trash")
                                }
                            }
                            .scaleEffect(animatedWalkIDs.contains(walk.id) ? 1 : 0.82)
                            .offset(y: animatedWalkIDs.contains(walk.id) ? 0 : 18)
                            .opacity(animatedWalkIDs.contains(walk.id) ? 1 : 0)
                            .onAppear {
                                animateCardIfNeeded(walkID: walk.id, index: index)
                            }
                            .accessibilityLabel(cardAccessibilityLabel(for: walk))
                            .accessibilityHint("Double tap to open artwork. Long press for more actions.")
                        }
                    }
                    .id(gridAnimationSeed)
                    .frame(maxWidth: .infinity)
                    .padding(.top, 6)

                    if displayed.count < filtered.count && didFinishDisplayingCurrentBatch {
                        Button {
                            loadMore(total: filtered.count)
                        } label: {
                            Text("Load More")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(AppTheme.actionPrimary)
                        .padding(.top, 8)
                    }
                }
            }
            .frame(maxWidth: .infinity)
        }
        .padding(16)
        .frame(maxWidth: .infinity)
        .background(AppTheme.pageBackground.ignoresSafeArea())
        .navigationTitle("Memory Wall")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarBackground(AppTheme.pageBackground, for: .navigationBar)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.headline.weight(.semibold))
                        .frame(minWidth: 44, minHeight: 44)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Back")
            }
        }
        .alert("Rename artwork", isPresented: renamePresentedBinding) {
            TextField("Artwork name", text: $renameInput)
            Button("Save") {
                guard let target = renameTarget else { return }
                store.rename(walkID: target.id, to: renameInput)
                renameTarget = nil
            }
            Button("Cancel", role: .cancel) {
                renameTarget = nil
            }
        } message: {
            Text("Up to \(store.artworkNameCharacterLimit) characters.")
        }
        .confirmationDialog("Delete this artwork?", isPresented: deletePresentedBinding, titleVisibility: .visible) {
            Button("Delete", role: .destructive) {
                if let target = deleteTarget {
                    store.delete(walkID: target.id)
                }
                deleteTarget = nil
            }
            Button("Cancel", role: .cancel) {
                deleteTarget = nil
            }
        } message: {
            Text("You can’t undo this action.")
        }
        .onChange(of: range) { _ in
            resetVisibleAndAnimationState()
        }
        .onChange(of: filteredWalks.map(\.id)) { _ in
            reconcileStateWithCurrentFilter()
        }
    }

    private var filteredWalks: [WalkRecord] {
        guard let days = range.days else {
            return store.walks
        }
        let start = Calendar.current.date(byAdding: .day, value: -days, to: Date()) ?? .distantPast
        return store.walks.filter { $0.timestampStart >= start }
    }

    private var renamePresentedBinding: Binding<Bool> {
        Binding(
            get: { renameTarget != nil },
            set: { isPresented in
                if !isPresented {
                    renameTarget = nil
                }
            }
        )
    }

    private var deletePresentedBinding: Binding<Bool> {
        Binding(
            get: { deleteTarget != nil },
            set: { isPresented in
                if !isPresented {
                    deleteTarget = nil
                }
            }
        )
    }

    private func shareText(for walk: WalkRecord) -> String {
        "\(store.displayName(for: walk)) · \(walk.timestampStart.formatted(date: .abbreviated, time: .shortened))"
    }

    private func cardAccessibilityLabel(for walk: WalkRecord) -> String {
        let name = store.displayName(for: walk)
        let date = walk.timestampStart.formatted(date: .abbreviated, time: .omitted)
        return "\(name), \(date)"
    }

    private func resetVisibleAndAnimationState() {
        visibleCount = pageSize
        animatedWalkIDs.removeAll()
        gridAnimationSeed = UUID()
    }

    private func loadMore(total: Int) {
        visibleCount = min(visibleCount + pageSize, total)
    }

    private func animateCardIfNeeded(walkID: String, index: Int) {
        guard !animatedWalkIDs.contains(walkID) else { return }

        let cappedDelay = min(Double(index) * 0.035, 0.55)
        withAnimation(.interpolatingSpring(stiffness: 250, damping: 18).delay(cappedDelay)) {
            _ = animatedWalkIDs.insert(walkID)
        }
    }

    private func reconcileStateWithCurrentFilter() {
        let currentIDs = Set(filteredWalks.map(\.id))
        animatedWalkIDs = animatedWalkIDs.intersection(currentIDs)

        if filteredWalks.isEmpty {
            visibleCount = pageSize
            return
        }

        visibleCount = max(pageSize, visibleCount)
        visibleCount = min(visibleCount, filteredWalks.count)
    }
}

private struct MemoryCell: View {
    let walk: WalkRecord
    let title: String

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            if let points = walk.artworkPoints, !points.isEmpty {
                let tint = (walk.moodColorHex.flatMap { Color(hex: $0) }) ?? AppTheme.actionPrimary
                ArtworkView(points: points, tint: tint, lineWidth: 3)
                    .overlay(alignment: .topTrailing) {
                        Image(systemName: "heart.fill")
                            .font(.footnote.weight(.semibold))
                            .foregroundStyle(tint)
                            .padding(10)
                            .accessibilityLabel("Mood")
                    }
            } else {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(AppTheme.canvasBackground)
                    .overlay {
                        Image(systemName: "scribble")
                            .foregroundStyle(AppTheme.textSecondary)
                            .accessibilityLabel("No artwork")
                    }
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.footnote.weight(.semibold))
                    .lineLimit(1)
                    .truncationMode(.tail)

                Text(walk.timestampStart, style: .date)
                    .font(.footnote.weight(.semibold))
            }
            .foregroundStyle(AppTheme.textPrimary)
            .padding(.horizontal, 8)
            .padding(.vertical, 6)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(AppTheme.cardBackground.opacity(0.92), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            .padding(10)
        }
        .aspectRatio(1, contentMode: .fit)
        .frame(maxWidth: .infinity)
        .padding(8)
        .background(AppTheme.cardBackground, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .strokeBorder(AppTheme.surfaceStroke.opacity(0.45))
        }
    }
}
