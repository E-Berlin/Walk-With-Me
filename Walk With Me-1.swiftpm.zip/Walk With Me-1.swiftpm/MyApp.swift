import SwiftUI

@main
struct MyApp: App {
    @StateObject private var store: WalkStore
    @StateObject private var locationManager: WalkLocationManager
    @StateObject private var session: WalkSessionViewModel

    init() {
        let lm = WalkLocationManager()
        _locationManager = StateObject(wrappedValue: lm)
        _session = StateObject(wrappedValue: WalkSessionViewModel(locationManager: lm))
        _store = StateObject(wrappedValue: WalkStore())
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .environmentObject(locationManager)
                .environmentObject(session)
        }
    }
}
