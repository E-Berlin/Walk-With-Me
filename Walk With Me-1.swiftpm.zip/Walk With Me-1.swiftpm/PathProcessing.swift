import CoreGraphics
import CoreLocation
import Foundation

enum PathProcessing {
    static func sortedByTimestamp(_ coords: [WalkCoordinate]) -> [WalkCoordinate] {
        coords.sorted { $0.timestamp < $1.timestamp }
    }

    static func normalize(_ coords: [WalkCoordinate]) -> [CGPoint] {
        let ordered = sortedByTimestamp(coords)
        guard ordered.count >= 2 else { return ordered.map { CGPoint(x: $0.latitude, y: $0.longitude) } }

        let xs = ordered.map(
            { $0.longitude }
        )
        let ys = ordered.map(
            { $0.latitude }
        )

        guard let minX = xs.min(), let maxX = xs.max(), let minY = ys.min(), let maxY = ys.max() else { return [] }

        let dx = max(maxX - minX, 0.0000001)
        let dy = max(maxY - minY, 0.0000001)
        let scale = max(dx, dy)

        return ordered.map { c in
            let nx = (c.longitude - minX) / scale
            let ny = (c.latitude - minY) / scale
            return CGPoint(x: nx, y: ny)
        }
    }

    static func normalizeMeters(_ coords: [WalkCoordinate]) -> [CGPoint] {
        let ordered = sortedByTimestamp(coords)
        guard !ordered.isEmpty else { return [] }

        let baseLat = ordered[0].latitude
        let baseLon = ordered[0].longitude
        let latFactor = 111_320.0
        let lonFactor = 111_320.0 * cos(baseLat * .pi / 180)

        let projected = ordered.map { c in
            CGPoint(
                x: (c.longitude - baseLon) * lonFactor,
                y: (c.latitude - baseLat) * latFactor
            )
        }

        guard projected.count >= 2 else { return projected }
        guard let minX = projected.map(\CGPoint.x).min(),
              let maxX = projected.map(\CGPoint.x).max(),
              let minY = projected.map(\CGPoint.y).min(),
              let maxY = projected.map(\CGPoint.y).max()
        else {
            return projected
        }

        let dx = max(maxX - minX, 0.00001)
        let dy = max(maxY - minY, 0.00001)
        let scale = max(dx, dy)

        return projected.map { point in
            CGPoint(x: (point.x - minX) / scale, y: (point.y - minY) / scale)
        }
    }

    static func fitNormalizedPointsToRect(_ normalizedPoints: [CGPoint], in rect: CGRect, padding: CGFloat = 12) -> [CGPoint] {
        guard normalizedPoints.count >= 2 else { return [] }

        let inset = rect.insetBy(dx: padding, dy: padding)
        guard inset.width > 0, inset.height > 0 else { return [] }

        let flipped = normalizedPoints.map { CGPoint(x: $0.x, y: 1 - $0.y) }

        let minX = flipped.map(\CGPoint.x).min() ?? 0
        let maxX = flipped.map(\CGPoint.x).max() ?? 1
        let minY = flipped.map(\CGPoint.y).min() ?? 0
        let maxY = flipped.map(\CGPoint.y).max() ?? 1

        let width = max(maxX - minX, 0.00001)
        let height = max(maxY - minY, 0.00001)
        let scale = min(inset.width / width, inset.height / height)

        let drawWidth = width * scale
        let drawHeight = height * scale
        let xOffset = inset.minX + (inset.width - drawWidth) / 2 - minX * scale
        let yOffset = inset.minY + (inset.height - drawHeight) / 2 - minY * scale

        return flipped.map { point in
            CGPoint(x: point.x * scale + xOffset, y: point.y * scale + yOffset)
        }
    }

    static func smooth(_ points: [CGPoint], window: Int = 5) -> [CGPoint] {
        guard points.count >= 3, window >= 3 else { return points }
        let w = max(3, window)
        let half = w / 2

        return points.indices.map { i in
            var sumX: CGFloat = 0
            var sumY: CGFloat = 0
            var count: CGFloat = 0
            let start = max(0, i - half)
            let end = min(points.count - 1, i + half)
            for j in start...end {
                sumX += points[j].x
                sumY += points[j].y
                count += 1
            }
            return CGPoint(x: sumX / count, y: sumY / count)
        }
    }

    static func simplifyRDP(_ points: [CGPoint], epsilon: CGFloat = 0.01) -> [CGPoint] {
        guard points.count >= 3 else { return points }

        func perpendicularDistance(_ p: CGPoint, _ a: CGPoint, _ b: CGPoint) -> CGFloat {
            let dx = b.x - a.x
            let dy = b.y - a.y
            if dx == 0 && dy == 0 { return hypot(p.x - a.x, p.y - a.y) }
            let t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / (dx * dx + dy * dy)
            let proj = CGPoint(x: a.x + t * dx, y: a.y + t * dy)
            return hypot(p.x - proj.x, p.y - proj.y)
        }

        func rdp(_ pts: [CGPoint]) -> [CGPoint] {
            guard pts.count >= 3 else { return pts }
            let a = pts.first!
            let b = pts.last!
            var maxDist: CGFloat = 0
            var index = 0
            for i in 1..<(pts.count - 1) {
                let d = perpendicularDistance(pts[i], a, b)
                if d > maxDist {
                    maxDist = d
                    index = i
                }
            }
            if maxDist > epsilon {
                let left = rdp(Array(pts[0...index]))
                let right = rdp(Array(pts[index...]))
                return Array(left.dropLast()) + right
            } else {
                return [a, b]
            }
        }

        return rdp(points)
    }

    static func generateArtworkPoints(from coords: [WalkCoordinate]) -> [NormalizedPoint] {
        let ordered = sortedByTimestamp(coords)
        guard ordered.count >= 2 else { return [] }

        let normalized = normalizeMeters(ordered)
        let smoothingWindow = min(5, max(3, (ordered.count / 10) * 2 + 1))
        let smoothed = smooth(normalized, window: smoothingWindow)
        let simplified = simplifyRDP(smoothed, epsilon: 0.004)
        return simplified.map { NormalizedPoint($0) }
    }
}
