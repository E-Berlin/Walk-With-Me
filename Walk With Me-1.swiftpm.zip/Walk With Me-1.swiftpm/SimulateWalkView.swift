import SwiftUI
#if canImport(UIKit)
import UIKit
#elseif canImport(AppKit)
import AppKit
#endif

struct SimulateWalkView: View {
    let onDone: () -> Void
    let onEnd: (_ artwork: [NormalizedPoint], _ duration: TimeInterval) -> Void

    @AppStorage("simulateBackgroundImageEnabled") private var backgroundImageEnabled: Bool = true

    @State private var samples: [Sample] = []
    @State private var lastDragAt: Date?
    @State private var dogState: DogState = .idle

    @State private var stateLockedUntil: Date = .distantPast

    @State private var renderedDogPosition: CGPoint?
    @State private var lastRenderTickAt: Date?
    @State private var followSpeedPointsPerSecond: CGFloat = 0
    @State private var idleStationaryDuration: TimeInterval = 0
    @State private var hasStartedWalking: Bool = false
    @State private var bubbleSemanticState: BubbleSemanticState = .idle
    @State private var bubbleText: String = "(•ᴥ•) 🐾 Hallo～"
    @State private var lastSniffingSwapAt: Date?
    @State private var entryAnimationProgress: CGFloat = 0
    @State private var showClearConfirmation: Bool = false
    @State private var showNavigationBar: Bool = false
    @State private var entrySequenceToken: UUID = UUID()
    @State private var dogEntryProgress: CGFloat = 0
    @State private var dogEntryScale: CGFloat = 1.34
    @State private var dogEntryJellySquash: CGFloat = 0.24

    @State private var canvasSize: CGSize = .zero

    private let maxSamples: Int = 900
    private let maxDogSpeedPointsPerSecond: CGFloat = 360
    private let leashDistanceForAnxiousEnter: CGFloat = 96
    private let leashDistanceForAnxiousExit: CGFloat = 72
    private let waitingSpeedThreshold: CGFloat = 8
    private let sniffingAfterStationarySeconds: TimeInterval = 3.0

    var body: some View {
        let bottomEntryOffset = 34 * (1 - entryAnimationProgress)

        ZStack {
            SimulateWalkBackground(showImage: backgroundImageEnabled)
                .ignoresSafeArea()

            GeometryReader { proxy in
                let size = proxy.size
                Color.clear
                    .onAppear {
                        canvasSize = size
                        if !hasStartedWalking && samples.isEmpty {
                            renderedDogPosition = initialDogPosition(in: size)
                            followSpeedPointsPerSecond = 0
                            idleStationaryDuration = 0
                            lastRenderTickAt = nil
                        }
                        if showNavigationBar, renderedDogPosition == nil {
                            renderedDogPosition = dogFollowPosition(in: size)
                        }
                    }
                    .onChange(of: size) { newSize in
                        canvasSize = newSize
                        if !hasStartedWalking && samples.isEmpty {
                            renderedDogPosition = initialDogPosition(in: newSize)
                            followSpeedPointsPerSecond = 0
                            idleStationaryDuration = 0
                            lastRenderTickAt = nil
                        }
                        if showNavigationBar, renderedDogPosition == nil {
                            renderedDogPosition = dogFollowPosition(in: newSize)
                        }
                    }

                Canvas { context, _ in
                    let path = smoothedPath(points: samples.map(\.point))
                    context.stroke(
                        path,
                        with: .color(AppTheme.actionPrimary.opacity(0.9)),
                        style: StrokeStyle(lineWidth: 6, lineCap: .round, lineJoin: .round)
                    )
                }
                .drawingGroup()
                .gesture(drawingGesture(in: size))
            }

            VStack {
                Spacer()

                VStack(spacing: 8) {
                    Text("Trace a walk path with your finger")
                        .font(.headline.weight(.semibold))
                        .foregroundStyle(AppTheme.textPrimary)

                    Text(statusLine)
                        .font(.body)
                        .foregroundStyle(AppTheme.textSecondary)

                    HStack(spacing: 10) {
                        Text("Background Image")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(AppTheme.textSecondary)
                        Spacer(minLength: 0)
                        Toggle("", isOn: $backgroundImageEnabled)
                            .labelsHidden()
                            .tint(AppTheme.actionPrimary)
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 12)
                .background(AppTheme.cardBackground.opacity(0.88), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .strokeBorder(AppTheme.surfaceStroke.opacity(0.45), lineWidth: 1)
                }
                .offset(y: bottomEntryOffset)
                .opacity(Double(max(0.001, entryAnimationProgress)))
                .padding(.bottom, 20)
            }

            GeometryReader { proxy in
                let size = proxy.size
                let targetPos = dogTargetPosition(in: size)
                let displayPos = renderedDogPosition ?? targetPos
                let dogEntryStartY = size.height + 96
                let dogPresentedY = dogEntryStartY + (displayPos.y - dogEntryStartY) * dogEntryProgress
                let presentedPos = CGPoint(x: displayPos.x, y: dogPresentedY)

                DogAvatar(
                    state: dogState,
                    position: presentedPos,
                    heading: 0,
                    shouldFloat: hasStartedWalking
                )
                .scaleEffect(
                    x: max(0.72, dogEntryScale * (1 + dogEntryJellySquash)),
                    y: max(0.72, dogEntryScale * (1 - dogEntryJellySquash * 0.55))
                )
                .allowsHitTesting(false)

                if let label = dogActionLabel {
                    let pos = presentedPos
                    let isAnxious = dogState == .anxious
                    let anxiousAlert = (Color(hex: "#E85A2A") ?? .orange)
                    let anxiousAlertBackground = (Color(hex: "#FFE7DA") ?? .orange)
                    Text(label)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(isAnxious ? anxiousAlert : AppTheme.textPrimary)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background((isAnxious ? anxiousAlertBackground : AppTheme.cardBackground).opacity(0.92), in: Capsule())
                        .overlay {
                            Capsule()
                                .strokeBorder((isAnxious ? anxiousAlert : AppTheme.surfaceStroke).opacity(0.45), lineWidth: 1)
                        }
                        .position(x: pos.x, y: min(size.height - 20, pos.y + 54))
                        .allowsHitTesting(false)
                }

                if let bubble = cuteBubbleText {
                    let pos = presentedPos
                    Text(bubble)
                        .font(.headline.weight(.semibold))
                        .foregroundStyle(AppTheme.textPrimary)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background(AppTheme.cardBackground.opacity(0.94), in: Capsule())
                        .overlay {
                            Capsule()
                                .strokeBorder(AppTheme.surfaceStroke.opacity(0.35), lineWidth: 1)
                        }
                        .position(x: pos.x + 40, y: max(26, pos.y - 52))
                        .allowsHitTesting(false)
                }
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .toolbar(showNavigationBar ? .visible : .hidden, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarBackground(AppTheme.pageBackground, for: .navigationBar)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button {
                    onDone()
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.title3.weight(.semibold))
                        .frame(minWidth: 44, minHeight: 44)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Back")
            }

            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    showClearConfirmation = true
                } label: {
                    Text("Clear")
                        .font(.headline.weight(.semibold))
                        .frame(minWidth: 72, minHeight: 44)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .foregroundStyle(AppTheme.textPrimary)
                .accessibilityLabel("Clear")
            }

            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    endSimulation()
                } label: {
                    Text("End")
                        .font(.headline.weight(.semibold))
                        .frame(minWidth: 72, minHeight: 44)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .foregroundStyle(AppTheme.textPrimary)
                .accessibilityLabel("End")
            }
        }
        .confirmationDialog("Reset this simulated walk?", isPresented: $showClearConfirmation, titleVisibility: .visible) {
            Button("Reset", role: .destructive) {
                clearSimulationState()
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This will clear the path and reset the dog state.")
        }
        .onAppear {
            let token = UUID()
            entrySequenceToken = token

            showNavigationBar = false
            entryAnimationProgress = 0
            dogEntryProgress = 0
            dogEntryScale = 1.34
            dogEntryJellySquash = 0.24

            withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) {
                entryAnimationProgress = 1
            }

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.16) {
                guard entrySequenceToken == token else { return }
                withAnimation(.easeOut(duration: 0.28)) {
                    showNavigationBar = true
                }
            }

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.66) {
                guard entrySequenceToken == token else { return }
                withAnimation(.spring(response: 0.88, dampingFraction: 0.8)) {
                    dogEntryProgress = 1
                }
                withAnimation(.interpolatingSpring(stiffness: 170, damping: 9)) {
                    dogEntryScale = 1.0
                    dogEntryJellySquash = 0
                }
            }
        }
        .onDisappear {
            entrySequenceToken = UUID()
            showNavigationBar = false
            dogEntryProgress = 0
            dogEntryScale = 1.34
            dogEntryJellySquash = 0.24
        }
        .onChange(of: showNavigationBar) { visible in
            guard visible, renderedDogPosition == nil else { return }
            renderedDogPosition = dogFollowPosition(in: canvasSize)
            lastRenderTickAt = nil
        }
        .task {
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 50_000_000)
                updateDogStateFromIdleTimeout()
                updateRenderedDogPosition()
                updateBubbleText()
            }
        }
    }

    private var statusLine: String {
        if !hasStartedWalking {
            return "Pause to let the dog settle. Tap Clear to reset."
        }
        if dogState == .anxious {
            return "Too fast and straight — slow down a little."
        }
        if isSniffing {
            return "The dog relaxes and sniffs around."
        }
        if isStationaryFollowing {
            return "Waiting..."
        }

        switch dogState {
        case .anxious:
            return "Too fast and straight — slow down a little."
        case .walking:
            return "Keep going — your path becomes a gentle trail."
        case .idle:
            return "Pause to let the dog settle. Tap Clear to reset."
        }
    }

    private var dogActionLabel: String? {
        guard hasStartedWalking else { return nil }
        if dogState == .anxious {
            return "Too fast!"
        }
        if isSniffing {
            return "Sniffing"
        }
        if isStationaryFollowing {
            return "Waiting"
        }

        switch dogState {
        case .walking:
            return "Walking"
        case .anxious:
            return "Too fast!"
        case .idle:
            return nil
        }
    }

    private var cuteBubbleText: String? {
        bubbleText
    }

    private var isStationaryFollowing: Bool {
        hasStartedWalking
            && !samples.isEmpty
            && followSpeedPointsPerSecond <= waitingSpeedThreshold
    }

    private var isSniffing: Bool {
        isStationaryFollowing
            && idleStationaryDuration >= sniffingAfterStationarySeconds
    }

    private func clearSimulationState() {
        samples = []
        lastDragAt = nil
        dogState = .idle
        renderedDogPosition = nil
        followSpeedPointsPerSecond = 0
        idleStationaryDuration = 0
        hasStartedWalking = false
        bubbleSemanticState = .idle
        bubbleText = "(•ᴥ•) 🐾 Hallo～"
        lastSniffingSwapAt = nil
    }

    private func endSimulation() {
        let artwork = simulatedArtworkPoints(from: samples.map(\.point))
        let duration: TimeInterval
        if let first = samples.first?.t, let last = samples.last?.t {
            duration = max(0, last.timeIntervalSince(first))
        } else {
            duration = 0
        }
        onEnd(artwork, duration)
    }

    private func drawingGesture(in size: CGSize) -> some Gesture {
        DragGesture(minimumDistance: 0, coordinateSpace: .local)
            .onChanged { value in
                lastDragAt = Date()
                if !hasStartedWalking {
                    hasStartedWalking = true
                }

                let point = clamped(value.location, in: size)
                let now = Date()

                if let last = samples.last {
                    let dist = hypot(point.x - last.point.x, point.y - last.point.y)
                    if dist < 1.5 { return }

                    let dogPos = dogFollowPosition(in: size)
                    let leashDistance = hypot(point.x - dogPos.x, point.y - dogPos.y)

                    let candidate = classifyDogState(
                        leashDistance: leashDistance,
                        currentState: dogState
                    )
                    let shouldForceUnlock = dogState == .anxious && leashDistance <= leashDistanceForAnxiousExit
                    applyCandidateState(candidate, force: shouldForceUnlock)
                } else {
                    applyCandidateState(.walking)
                }

                samples.append(Sample(point: point, t: now))
                if samples.count > maxSamples {
                    samples.removeFirst(samples.count - maxSamples)
                }
            }
            .onEnded { _ in
                // Dog state will transition to .idle after timeout.
            }
    }

    private func classifyDogState(leashDistance: CGFloat, currentState: DogState) -> DogState {
        if currentState == .anxious {
            if leashDistance >= leashDistanceForAnxiousExit {
                return .anxious
            }
        } else if leashDistance >= leashDistanceForAnxiousEnter {
            return .anxious
        }
        return .walking
    }

    private func applyCandidateState(_ candidate: DogState, force: Bool = false) {
        let now = Date()
        guard force || now >= stateLockedUntil || candidate == dogState else {
            return
        }
        guard candidate != dogState else { return }

        dogState = candidate
        let hold: TimeInterval
        switch candidate {
        case .anxious:
            hold = 0.75
        case .walking:
            hold = 0.45
        case .idle:
            hold = 0
        }
        stateLockedUntil = now.addingTimeInterval(hold)
    }

    private func updateDogStateFromIdleTimeout() {
        guard let lastDragAt else {
            if dogState != .idle {
                dogState = .idle
            }
            return
        }
        if Date().timeIntervalSince(lastDragAt) > 1.1 {
            if hasStartedWalking {
                if dogState != .walking {
                    dogState = .walking
                }
            } else if dogState != .idle {
                dogState = .idle
            }
        }
    }

    private func dogTargetPosition(in size: CGSize) -> CGPoint {
        if let last = samples.last?.point {
            return last
        }
        return initialDogPosition(in: size)
    }

    private func dogFollowPosition(in size: CGSize) -> CGPoint {
        renderedDogPosition ?? initialDogPosition(in: size)
    }

    private func initialDogPosition(in size: CGSize) -> CGPoint {
        CGPoint(x: size.width / 2, y: size.height - 172)
    }

    private func updateRenderedDogPosition() {
        guard showNavigationBar else { return }

        let size = canvasSize
        guard size.width > 1, size.height > 1 else { return }

        let target = dogTargetPosition(in: size)
        let current = dogFollowPosition(in: size)

        let now = Date()
        let dt: CGFloat
        if let last = lastRenderTickAt {
            dt = max(0.001, min(0.2, CGFloat(now.timeIntervalSince(last))))
        } else {
            dt = 0.05
        }
        lastRenderTickAt = now

        let alpha: CGFloat = dogState == .idle ? 0.06 : 0.10
        var step = CGVector(dx: (target.x - current.x) * alpha, dy: (target.y - current.y) * alpha)

        let stepDistance = hypot(step.dx, step.dy)
        let maxDistance = maxDogSpeedPointsPerSecond * dt
        if stepDistance > maxDistance {
            let scale = maxDistance / max(stepDistance, 0.0001)
            step.dx *= scale
            step.dy *= scale
        }

        let next = CGPoint(x: current.x + step.dx, y: current.y + step.dy)
        renderedDogPosition = next

        followSpeedPointsPerSecond = hypot(next.x - current.x, next.y - current.y) / max(dt, 0.001)
        if isStationaryFollowing {
            idleStationaryDuration += dt
        } else {
            idleStationaryDuration = 0
        }
    }

    private func updateBubbleText() {
        let currentSemanticState: BubbleSemanticState
        if dogState == .anxious {
            currentSemanticState = .anxious
        } else if !hasStartedWalking {
            currentSemanticState = .idle
        } else if isSniffing {
            currentSemanticState = .sniffing
        } else if isStationaryFollowing {
            currentSemanticState = .waiting
        } else {
            currentSemanticState = .walking
        }

        if currentSemanticState != bubbleSemanticState {
            bubbleSemanticState = currentSemanticState
            bubbleText = randomBubble(for: currentSemanticState)
            lastSniffingSwapAt = Date()
            return
        }

        guard currentSemanticState == .sniffing else { return }

        let now = Date()
        if let last = lastSniffingSwapAt,
           now.timeIntervalSince(last) < 2.3 {
            return
        }
        lastSniffingSwapAt = now
        let sniffingPool = ["..?", "..!", "🫧?", "👃✨", "sniff~", "🐾?", "oᴥo ?"]
        bubbleText = sniffingPool.randomElement() ?? "..?"
    }

    private func randomBubble(for semanticState: BubbleSemanticState) -> String {
        switch semanticState {
        case .walking:
            let pool = ["( ᵔᴥᵔ ) ♪", "✨🐾", "( ^ᴥ^ ) ♡"]
            return pool.randomElement() ?? "( ᵔᴥᵔ ) ♪"
        case .anxious:
            let pool = ["(>ᴥ<) 💦💦", "(TᴥT) 💦💦", "( ;ᴥ; ) 💦💦", "!!"]
            return pool.randomElement() ?? "(>ᴥ<) 💦💦"
        case .waiting:
            let pool = ["(zᴥz) 💤", "( ˘ᴥ˘ ) 💤", "💤", "...", "ᵕ̈"]
            return pool.randomElement() ?? "(zᴥz) 💤"
        case .idle:
            return "(•ᴥ•) 🐾 Hallo～"
        case .sniffing:
            let pool = ["..?", "..!", "🫧?", "👃✨", "sniff~", "🐾?", "oᴥo ?"]
            return pool.randomElement() ?? "..?"
        }
    }

    private func dogHeadingAngleRadians() -> Double {
        guard samples.count >= 2 else { return 0 }
        let a = samples[samples.count - 2].point
        let b = samples[samples.count - 1].point
        return atan2(Double(b.y - a.y), Double(b.x - a.x))
    }

    private func clamped(_ p: CGPoint, in size: CGSize) -> CGPoint {
        CGPoint(
            x: min(max(0, p.x), size.width),
            y: min(max(0, p.y), size.height)
        )
    }

    private func clampedLabelX(_ x: CGFloat, in size: CGSize) -> CGFloat {
        min(max(60, x), max(60, size.width - 60))
    }

    private func smoothedPath(points: [CGPoint]) -> Path {
        guard points.count >= 2 else {
            var p = Path()
            if let first = points.first {
                p.addEllipse(in: CGRect(x: first.x - 2, y: first.y - 2, width: 4, height: 4))
            }
            return p
        }

        var path = Path()
        path.move(to: points[0])

        if points.count == 2 {
            path.addLine(to: points[1])
            return path
        }

        for i in 1..<(points.count - 1) {
            let prev = points[i - 1]
            let current = points[i]
            let next = points[i + 1]

            let mid = CGPoint(x: (current.x + next.x) / 2, y: (current.y + next.y) / 2)
            let control = CGPoint(x: current.x + (next.x - prev.x) / 6, y: current.y + (next.y - prev.y) / 6)
            path.addQuadCurve(to: mid, control: control)
        }

        if let last = points.last {
            path.addLine(to: last)
        }
        return path
    }

    private func simulatedArtworkPoints(from points: [CGPoint]) -> [NormalizedPoint] {
        guard points.count >= 2 else { return [] }
        guard let minX = points.map(\.x).min(),
              let maxX = points.map(\.x).max(),
              let minY = points.map(\.y).min(),
              let maxY = points.map(\.y).max()
        else {
            return []
        }

        let width = max(maxX - minX, 0.0001)
        let height = max(maxY - minY, 0.0001)
        let scale = max(width, height)

        return points.map { point in
            let normalized = CGPoint(
                x: (point.x - minX) / scale,
                y: 1 - ((point.y - minY) / scale)
            )
            return NormalizedPoint(normalized)
        }
    }
}

private struct SimulateWalkBackground: View {
    let showImage: Bool

    @State private var imageFadeProgress: CGFloat = 0

    private let backgroundAssetName = "image"

    private var hasBackgroundAsset: Bool {
        #if canImport(UIKit)
        UIImage(named: backgroundAssetName) != nil
        #elseif canImport(AppKit)
        NSImage(named: backgroundAssetName) != nil
        #else
        false
        #endif
    }

    private var shouldShowAssetImage: Bool {
        showImage && hasBackgroundAsset
    }

    var body: some View {
        let homeTopBackground = (Color(hex: "#ecce95") ?? AppTheme.pageBackground)
        ZStack {
            homeTopBackground

            if shouldShowAssetImage {
                GeometryReader { proxy in
                    let size = proxy.size
                    Image(backgroundAssetName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: size.width * 0.98)
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                        .offset(y: 44)
                        .opacity(Double(max(0.001, imageFadeProgress)))
                        .transition(.opacity)
                }
                .ignoresSafeArea()
            }

            Canvas { context, size in
                let dotColor = AppTheme.surfaceStroke.opacity(0.06)
                for i in stride(from: 0, to: Int(size.width), by: 18) {
                    for j in stride(from: 0, to: Int(size.height), by: 22) {
                        if (i + j) % 3 != 0 { continue }
                        let rect = CGRect(x: CGFloat(i), y: CGFloat(j), width: 2.2, height: 2.2)
                        context.fill(Path(ellipseIn: rect), with: .color(dotColor))
                    }
                }
            }
            .opacity(0.9)
        }
        .onAppear {
            imageFadeProgress = 0
            guard shouldShowAssetImage else { return }
            withAnimation(.easeInOut(duration: 0.55).delay(0.12)) {
                imageFadeProgress = 1
            }
        }
        .onChange(of: shouldShowAssetImage) { show in
            withAnimation(.easeInOut(duration: 0.35)) {
                imageFadeProgress = show ? 1 : 0
            }
        }
        .onDisappear {
            imageFadeProgress = 0
        }
    }
}

private struct DogAvatar: View {
    let state: DogState
    let position: CGPoint
    let heading: Double
    let shouldFloat: Bool

    @State private var wag: Bool = false

    var body: some View {
        let scale: CGFloat = {
            switch state {
            case .anxious: return 1.1
            case .walking: return 1.05
            case .idle: return 1.0
            }
        }()

        let bounce: CGFloat = {
            switch state {
            case .anxious: return 10
            case .walking: return 7
            case .idle: return 0
            }
        }()

        let rotation: Double = {
            0
        }()
        ZStack {
            Text("🐶")
                .font(.system(size: 60))
                .shadow(color: AppTheme.textPrimary.opacity(0.12), radius: 6, x: 0, y: 4)
        }
        .scaleEffect(scale)
        .rotationEffect(.radians(rotation))
        .position(x: position.x, y: position.y)
        .offset(y: (shouldFloat && wag) ? -bounce : 0)
        .animation(.easeInOut(duration: 0.28), value: state)
        .onAppear {
            wag = shouldFloat
        }
        .onChange(of: state) { _ in
            guard shouldFloat else { return }
            wag.toggle()
        }
        .onChange(of: shouldFloat) { enabled in
            if enabled {
                wag = true
            } else {
                wag = false
            }
        }
        .animation(
            shouldFloat
                ? .easeInOut(duration: state == .idle ? 0.9 : 0.35).repeatForever(autoreverses: true)
                : .none,
            value: wag
        )
    }
}

private struct Sample {
    let point: CGPoint
    let t: Date
}

private enum DogState: String {
    case walking
    case anxious
    case idle
}

private enum BubbleSemanticState {
    case walking
    case anxious
    case waiting
    case idle
    case sniffing
}
