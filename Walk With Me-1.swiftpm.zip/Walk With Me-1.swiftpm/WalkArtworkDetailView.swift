import SwiftUI

struct WalkArtworkDetailView: View {
    @EnvironmentObject private var store: WalkStore

    let walkID: String
    let showToGalleryButton: Bool
    let backButtonTitle: String?
    let onBack: () -> Void
    let onToGallery: () -> Void
    let onDeleted: () -> Void

    @State private var showDeleteDialog: Bool = false
    @State private var showRenameAlert: Bool = false
    @State private var renameInput: String = ""

    var body: some View {
        Group {
            if let walk {
                VStack(alignment: .leading, spacing: 16) {
                    HStack(spacing: 8) {
                        Text(store.displayName(for: walk))
                            .font(.title3.weight(.semibold))
                            .foregroundStyle(AppTheme.textPrimary)
                            .lineLimit(1)
                            .truncationMode(.tail)

                        Button {
                            renameInput = store.displayName(for: walk)
                            showRenameAlert = true
                        } label: {
                            Image(systemName: "pencil.line")
                                .font(.title3.weight(.black))
                                .foregroundStyle(AppTheme.textSecondary)
                                .frame(minWidth: 44, minHeight: 44)
                                .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Rename artwork")

                        Spacer()
                    }

                    if let points = walk.artworkPoints, !points.isEmpty {
                        ArtworkView(points: points, tint: tint(for: walk), lineWidth: 4)
                            .frame(maxWidth: .infinity)
                            .transition(.opacity.combined(with: .scale(scale: 0.98)))
                    } else {
                        EmptyStateView(
                            title: "No artwork",
                            systemImage: "scribble",
                            message: "This walk has no generated artwork."
                        )
                        .frame(maxWidth: .infinity)
                    }

                    Text(walk.timestampStart.formatted(date: .abbreviated, time: .shortened))
                        .font(.subheadline)
                        .foregroundStyle(AppTheme.textSecondary)

                    Spacer()

                    VStack(spacing: 10) {
                        HStack(spacing: 10) {
                            ShareLink(item: shareText(for: walk)) {
                                Label("Share", systemImage: "square.and.arrow.up")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 12)
                            }
                            .buttonStyle(.bordered)
                            .tint(AppTheme.actionSecondary)

                            Button(role: .destructive) {
                                showDeleteDialog = true
                            } label: {
                                Label("Delete", systemImage: "trash")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 12)
                            }
                            .buttonStyle(.bordered)
                            .tint(AppTheme.destructive)
                        }

                        if showToGalleryButton {
                            Button {
                                onToGallery()
                            } label: {
                                Label("To Gallery", systemImage: "square.grid.2x2")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 14)
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(AppTheme.actionPrimary)
                        }
                    }
                    .frame(maxWidth: .infinity)
                }
                .padding(20)
                .frame(maxWidth: .infinity)
                .background(AppTheme.pageBackground.ignoresSafeArea())
                .navigationTitle("Artwork")
                .navigationBarTitleDisplayMode(.inline)
                .navigationBarBackButtonHidden(backButtonTitle != nil)
                .toolbarBackground(.visible, for: .navigationBar)
                .toolbarBackground(AppTheme.pageBackground, for: .navigationBar)
                .toolbar {
                    if backButtonTitle != nil {
                        ToolbarItem(placement: .topBarLeading) {
                            Button {
                                onBack()
                            } label: {
                                Image(systemName: "chevron.left")
                                    .font(.headline.weight(.semibold))
                                    .frame(minWidth: 44, minHeight: 44)
                                    .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel("Back")
                        }
                    }
                }
                .confirmationDialog("Delete this walk?", isPresented: $showDeleteDialog, titleVisibility: .visible) {
                    Button("Confirm Delete", role: .destructive) {
                        store.delete(walkID: walkID)
                        onDeleted()
                    }
                    Button("Cancel", role: .cancel) {}
                } message: {
                    Text("You can’t undo this action.")
                }
                .alert("Rename artwork", isPresented: $showRenameAlert) {
                    TextField("Artwork name", text: $renameInput)
                    Button("Save") {
                        store.rename(walkID: walkID, to: renameInput)
                    }
                    Button("Cancel", role: .cancel) {}
                } message: {
                    Text("Up to \(store.artworkNameCharacterLimit) characters.")
                }
            } else {
                EmptyStateView(
                    title: "Missing artwork",
                    systemImage: "exclamationmark.triangle",
                    message: "This walk was removed."
                )
                .padding(20)
                .background(AppTheme.pageBackground.ignoresSafeArea())
                .navigationTitle("Artwork")
                .navigationBarTitleDisplayMode(.inline)
            }
        }
    }

    private var walk: WalkRecord? {
        store.walk(withID: walkID)
    }

    private func tint(for walk: WalkRecord) -> Color {
        (walk.moodColorHex.flatMap { Color(hex: $0) }) ?? AppTheme.actionPrimary
    }

    private func shareText(for walk: WalkRecord) -> String {
        "Walk artwork from \(walk.timestampStart.formatted(date: .abbreviated, time: .shortened)) in Walk With Me"
    }
}
