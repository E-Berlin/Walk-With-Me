import Foundation

enum WalkLifecycle: String {
    case idle
    case recording
    case processing
    case moodSelection
    case saved
}
