import CoreLocation
import Foundation

@MainActor
final class WalkLocationManager: NSObject, ObservableObject {
    @Published private(set) var authorizationStatus: CLAuthorizationStatus = .notDetermined
    @Published private(set) var isUpdating: Bool = false
    @Published private(set) var lastCoordinate: WalkCoordinate?

    private let manager = CLLocationManager()
    private var pendingStartRequest: Bool = false

    override init() {
        super.init()
        manager.delegate = self
        manager.activityType = .fitness
        manager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        manager.distanceFilter = 2
        manager.allowsBackgroundLocationUpdates = false
        manager.pausesLocationUpdatesAutomatically = false
        authorizationStatus = manager.authorizationStatus
    }

    func requestAuthorizationIfNeeded() {
        let status = manager.authorizationStatus
        authorizationStatus = status
        switch status {
        case .notDetermined:
            manager.requestWhenInUseAuthorization()
        default:
            break
        }
    }

    func startUpdates() {
        pendingStartRequest = true
        requestAuthorizationIfNeeded()
        guard manager.authorizationStatus == .authorizedWhenInUse || manager.authorizationStatus == .authorizedAlways else {
            return
        }
        if isUpdating { return }
        isUpdating = true

        if let cached = manager.location,
           cached.horizontalAccuracy > 0,
           cached.horizontalAccuracy <= 200,
           abs(cached.timestamp.timeIntervalSinceNow) <= 300 {
            lastCoordinate = WalkCoordinate(location: cached)
        }

        manager.requestLocation()
        manager.startUpdatingLocation()
    }

    func stopUpdates() {
        pendingStartRequest = false
        guard isUpdating else { return }
        isUpdating = false
        manager.stopUpdatingLocation()
    }
}

extension WalkLocationManager: CLLocationManagerDelegate {
    nonisolated func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        let status = manager.authorizationStatus
        Task { @MainActor in
            self.authorizationStatus = status

            guard self.pendingStartRequest else { return }
            guard status == .authorizedWhenInUse || status == .authorizedAlways else { return }
            guard !self.isUpdating else { return }

            self.isUpdating = true
            self.manager.requestLocation()
            self.manager.startUpdatingLocation()
        }
    }

    nonisolated func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let preferredMaxHorizontalAccuracyMeters: CLLocationAccuracy = 35
        let preferredMaxLocationAgeSeconds: TimeInterval = 8
        let fallbackMaxHorizontalAccuracyMeters: CLLocationAccuracy = 200
        let fallbackMaxLocationAgeSeconds: TimeInterval = 60
        let now = Date()

        if let preferred = locations.reversed().first(where: { location in
            location.horizontalAccuracy > 0 &&
                location.horizontalAccuracy <= preferredMaxHorizontalAccuracyMeters &&
                abs(location.timestamp.timeIntervalSince(now)) <= preferredMaxLocationAgeSeconds
        }) {
            let coordinate = WalkCoordinate(location: preferred)
            Task { @MainActor in
                self.lastCoordinate = coordinate
            }
            return
        } else {
            let fallback = locations.reversed().first(where: { location in
                location.horizontalAccuracy > 0 &&
                    location.horizontalAccuracy <= fallbackMaxHorizontalAccuracyMeters &&
                    abs(location.timestamp.timeIntervalSince(now)) <= fallbackMaxLocationAgeSeconds
            })
            guard let fallback else { return }

            let coordinate = WalkCoordinate(location: fallback)
            Task { @MainActor in
                self.lastCoordinate = coordinate
            }
            return
        }
    }

    nonisolated func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        // For MVP: ignore, UI can show "No GPS" by lack of points.
    }
}
