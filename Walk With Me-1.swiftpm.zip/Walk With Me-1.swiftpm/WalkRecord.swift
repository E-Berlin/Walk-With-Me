import Foundation
import CoreLocation
import SwiftUI

struct WalkCoordinate: Codable, Hashable, Identifiable {
    var id: UUID = UUID()
    var latitude: Double
    var longitude: Double
    var timestamp: Date

    init(latitude: Double, longitude: Double, timestamp: Date) {
        self.latitude = latitude
        self.longitude = longitude
        self.timestamp = timestamp
    }

    init(location: CLLocation) {
        self.latitude = location.coordinate.latitude
        self.longitude = location.coordinate.longitude
        self.timestamp = location.timestamp
    }
}

struct NormalizedPoint: Codable, Hashable, Identifiable {
    var id: UUID = UUID()
    var x: Double
    var y: Double

    init(x: Double, y: Double) {
        self.x = x
        self.y = y
    }

    init(_ point: CGPoint) {
        self.x = Double(point.x)
        self.y = Double(point.y)
    }

    var cgPoint: CGPoint { CGPoint(x: x, y: y) }
}

struct WalkRecord: Codable, Identifiable, Hashable {
    var id: String

    var timestampStart: Date
    var timestampEnd: Date?

    var duration: TimeInterval

    var pathCoordinates: [WalkCoordinate]

    var moodColorHex: String?

    var artworkName: String?

    var styleType: String

    var artworkPoints: [NormalizedPoint]?

    init(
        id: String = UUID().uuidString,
        timestampStart: Date,
        timestampEnd: Date? = nil,
        duration: TimeInterval = 0,
        pathCoordinates: [WalkCoordinate] = [],
        moodColorHex: String? = nil,
        artworkName: String? = nil,
        styleType: String = "default",
        artworkPoints: [NormalizedPoint]? = nil
    ) {
        self.id = id
        self.timestampStart = timestampStart
        self.timestampEnd = timestampEnd
        self.duration = duration
        self.pathCoordinates = pathCoordinates
        self.moodColorHex = moodColorHex
        self.artworkName = artworkName
        self.styleType = styleType
        self.artworkPoints = artworkPoints
    }
}

extension Color {
    init?(hex: String) {
        var trimmed = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.hasPrefix("#") { trimmed.removeFirst() }
        guard trimmed.count == 6, let value = UInt64(trimmed, radix: 16) else { return nil }
        let r = Double((value >> 16) & 0xFF) / 255
        let g = Double((value >> 8) & 0xFF) / 255
        let b = Double(value & 0xFF) / 255
        self = Color(.sRGB, red: r, green: g, blue: b, opacity: 1)
    }

    func toHex() -> String? {
        #if canImport(UIKit)
        let uiColor = UIColor(self)
        var r: CGFloat = 0
        var g: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        guard uiColor.getRed(&r, green: &g, blue: &b, alpha: &a) else { return nil }
        let ri = Int(round(r * 255))
        let gi = Int(round(g * 255))
        let bi = Int(round(b * 255))
        return String(format: "#%02X%02X%02X", ri, gi, bi)
        #else
        return nil
        #endif
    }
}
