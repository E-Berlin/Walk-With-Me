import MapKit
import SwiftUI

struct WalkRecordingView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var session: WalkSessionViewModel
    @EnvironmentObject private var locationManager: WalkLocationManager

    @State private var shouldLoadMap: Bool = false
    @State private var isMapReady: Bool = false
    @State private var gridMaskOpacity: Double = 1
    @State private var contentEntryProgress: CGFloat = 0
    @State private var didRunEntrySequence: Bool = false
    @State private var isRecordingStarted: Bool = false
    @State private var showNavigationBar: Bool = false
    @State private var entrySequenceToken: UUID = UUID()

    let startRecording: () -> Void
    let endWalk: () -> Void

    private var walkingStatusTitle: String {
        session.isPaused ? "Pause" : "Walking"
    }

    var body: some View {
        let ordered = PathProcessing.sortedByTimestamp(session.livePath)
        let distanceMeters = totalDistanceMeters(ordered)
        let displayElapsed = isRecordingStarted ? session.elapsed : 0
        let topEntryOffset = -96 * (1 - contentEntryProgress)
        let bottomEntryOffset = 116 * (1 - contentEntryProgress)
        let contentEntryOpacity = 0.35 + (0.65 * contentEntryProgress)

        ZStack {
            AppTheme.pageBackground
                .ignoresSafeArea()

            if shouldLoadMap {
                LivePathMapBackground(
                    coordinates: ordered,
                    focusCoordinate: locationManager.lastCoordinate,
                    onMapFullyRendered: handleMapFullyRendered
                )
                .transaction { transaction in
                    transaction.animation = nil
                }
                .ignoresSafeArea()
            }

            LinearGradient(
                colors: [AppTheme.pageBackground.opacity(0.08), AppTheme.pageBackground.opacity(0.34)],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            .allowsHitTesting(false)

            if gridMaskOpacity > 0.001 {
                GridLoadingMask(fillColor: AppTheme.pageBackground, lineColor: AppTheme.surfaceStroke)
                    .opacity(gridMaskOpacity)
                    .allowsHitTesting(false)
                    .ignoresSafeArea()
            }

            VStack(spacing: 16) {
                VStack(spacing: 10) {
                    HStack {
                        Image(systemName: "record.circle")
                            .symbolRenderingMode(.hierarchical)
                            .foregroundStyle(
                                !isRecordingStarted ? AppTheme.actionPrimary :
                                    (session.isPaused ? AppTheme.recordingPaused : AppTheme.recordingActive)
                            )
                            .accessibilityLabel(!isRecordingStarted ? "Preparing" : walkingStatusTitle)
                        Text(!isRecordingStarted ? "Preparing" : walkingStatusTitle)
                            .font(.headline)
                            .foregroundStyle(AppTheme.textPrimary)
                        Spacer()
                    }

                    Text(formattedDuration(displayElapsed))
                        .font(.largeTitle.weight(.semibold))
                        .monospacedDigit()
                        .foregroundStyle(AppTheme.textPrimary)
                        .accessibilityLabel("Duration")

                    Text(formattedDistance(distanceMeters))
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(AppTheme.textSecondary)
                        .accessibilityLabel("Distance")
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 12)
                .frame(maxWidth: .infinity)
                .background(AppTheme.cardBackground.opacity(0.96), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .strokeBorder(AppTheme.surfaceStroke.opacity(0.5), lineWidth: 1)
                }
                .animation(.spring(response: 0.25, dampingFraction: 0.82), value: session.isPaused)
                .offset(y: topEntryOffset)
                .opacity(contentEntryOpacity)

                if !isAuthorized {
                    LocationPermissionNote()
                        .frame(maxWidth: .infinity)
                        .transition(.opacity)
                        .offset(y: topEntryOffset)
                        .opacity(contentEntryOpacity)
                }

                if ordered.count < 2 {
                    VStack(spacing: 6) {
                        Label("Finding GPS…", systemImage: "location")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(AppTheme.textPrimary)
                        Text("Walk a little to start drawing the path.")
                            .font(.footnote)
                            .foregroundStyle(AppTheme.textSecondary)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 10)
                    .background(AppTheme.cardBackground.opacity(0.95), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay {
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .strokeBorder(AppTheme.surfaceStroke.opacity(0.5), lineWidth: 1)
                    }
                    .transition(.opacity.combined(with: .move(edge: .top)))
                    .offset(y: topEntryOffset)
                    .opacity(contentEntryOpacity)
                }

                Spacer()

                VStack(spacing: 10) {
                    Button {
                        session.togglePause()
                    } label: {
                        Label(session.isPaused ? "Resume" : "Pause", systemImage: session.isPaused ? "play.fill" : "pause.fill")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                    }
                    .buttonStyle(.bordered)
                    .tint(session.isPaused ? AppTheme.actionPrimary : AppTheme.actionSecondary)
                    .animation(.spring(response: 0.25, dampingFraction: 0.8), value: session.isPaused)
                    .accessibilityLabel(session.isPaused ? "Resume recording" : "Pause recording")
                    .disabled(!isRecordingStarted)

                    Button(role: .destructive) {
                        endWalk()
                    } label: {
                        Label("End Walk", systemImage: "stop.fill")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(AppTheme.destructive)
                    .accessibilityLabel("End walk")
                    .disabled(!isRecordingStarted)
                }
                .frame(maxWidth: .infinity)
                .padding(14)
                .background(AppTheme.cardBackground.opacity(0.96), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .strokeBorder(AppTheme.surfaceStroke.opacity(0.5), lineWidth: 1)
                }
                .offset(y: bottomEntryOffset)
                .opacity(contentEntryOpacity)

                Text("Preparing walk…")
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(AppTheme.textSecondary)
                    .padding(.top, 2)
                    .frame(height: 20)
                    .offset(y: bottomEntryOffset)
                    .opacity((isRecordingStarted ? 0 : 1) * contentEntryOpacity)
                    .accessibilityLabel("Preparing walk")
            }
            .padding(20)
            .frame(maxWidth: .infinity)
        }
        .navigationTitle("Walk")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .toolbar(showNavigationBar ? .visible : .hidden, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarBackground(AppTheme.pageBackground, for: .navigationBar)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.headline.weight(.semibold))
                        .frame(minWidth: 44, minHeight: 44)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Back")
            }
        }
        .task {
            locationManager.requestAuthorizationIfNeeded()
        }
        .onAppear {
            runEntrySequenceIfNeeded()
        }
        .onDisappear {
            didRunEntrySequence = false
            entrySequenceToken = UUID()
            showNavigationBar = false
            shouldLoadMap = false
            isMapReady = false
            gridMaskOpacity = 1
            contentEntryProgress = 0
            isRecordingStarted = false
        }
    }

    private func runEntrySequenceIfNeeded() {
        guard !didRunEntrySequence else { return }

        didRunEntrySequence = true
        let token = UUID()
        entrySequenceToken = token

        shouldLoadMap = false
        isMapReady = false
        gridMaskOpacity = 1
        contentEntryProgress = 0
        isRecordingStarted = false
        showNavigationBar = false

        withAnimation(.easeInOut(duration: 0.46).delay(0.08)) {
            contentEntryProgress = 1
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.56) {
            guard entrySequenceToken == token else { return }
            shouldLoadMap = true
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) {
            guard entrySequenceToken == token else { return }
            withAnimation(.easeOut(duration: 0.28)) {
                showNavigationBar = true
            }
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.62) {
            guard entrySequenceToken == token else { return }
            startRecording()
            withAnimation(.easeOut(duration: 0.2)) {
                isRecordingStarted = true
            }
        }
    }

    private func handleMapFullyRendered() {
        guard shouldLoadMap else { return }
        guard !isMapReady else { return }

        isMapReady = true
        withAnimation(.easeOut(duration: 0.36)) {
            gridMaskOpacity = 0
        }
    }

    private var isAuthorized: Bool {
        switch locationManager.authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse:
            return true
        default:
            return false
        }
    }

    private func formattedDuration(_ interval: TimeInterval) -> String {
        let total = Int(interval)
        let m = total / 60
        let s = total % 60
        return String(format: "%02d:%02d", m, s)
    }

    private func totalDistanceMeters(_ coords: [WalkCoordinate]) -> CLLocationDistance {
        guard coords.count >= 2 else { return 0 }

        var total: CLLocationDistance = 0
        for i in 1..<coords.count {
            let from = CLLocation(latitude: coords[i - 1].latitude, longitude: coords[i - 1].longitude)
            let to = CLLocation(latitude: coords[i].latitude, longitude: coords[i].longitude)
            total += from.distance(from: to)
        }
        return total
    }

    private func formattedDistance(_ meters: CLLocationDistance) -> String {
        if meters >= 1000 {
            return String(format: "%.2f km", meters / 1000)
        }
        return "\(Int(meters.rounded())) m"
    }
}

private struct GridLoadingMask: View {
    let fillColor: Color
    let lineColor: Color

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                fillColor.opacity(0.76)

                Path { path in
                    let step: CGFloat = 24
                    var x: CGFloat = 0
                    while x <= proxy.size.width {
                        path.move(to: CGPoint(x: x, y: 0))
                        path.addLine(to: CGPoint(x: x, y: proxy.size.height))
                        x += step
                    }

                    var y: CGFloat = 0
                    while y <= proxy.size.height {
                        path.move(to: CGPoint(x: 0, y: y))
                        path.addLine(to: CGPoint(x: proxy.size.width, y: y))
                        y += step
                    }
                }
                .stroke(lineColor.opacity(0.24), lineWidth: 1)
            }
            .frame(width: proxy.size.width, height: proxy.size.height)
        }
    }
}

private struct LivePathMapBackground: UIViewRepresentable {
    let coordinates: [WalkCoordinate]
    let focusCoordinate: WalkCoordinate?
    let onMapFullyRendered: () -> Void

    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView(frame: .zero)
        mapView.delegate = context.coordinator
        mapView.userTrackingMode = .none
        mapView.isRotateEnabled = false
        mapView.isPitchEnabled = false
        mapView.showsCompass = false
        mapView.showsScale = false
        mapView.pointOfInterestFilter = .excludingAll
        mapView.mapType = .mutedStandard
        mapView.showsUserLocation = true
        mapView.isUserInteractionEnabled = false
        return mapView
    }

    func updateUIView(_ mapView: MKMapView, context: Context) {
        if coordinates.count < 2 {
            if let existing = context.coordinator.polyline {
                mapView.removeOverlay(existing)
                context.coordinator.polyline = nil
                context.coordinator.lastRenderedPointCount = 0
            }
            if let focusCoordinate {
                let center = CLLocationCoordinate2D(latitude: focusCoordinate.latitude, longitude: focusCoordinate.longitude)
                let region = MKCoordinateRegion(center: center, latitudinalMeters: 220, longitudinalMeters: 220)
                if !context.coordinator.didSetInitialRegion {
                    mapView.setRegion(region, animated: false)
                    context.coordinator.didSetInitialRegion = true
                }
            }
            return
        }

        let ordered = PathProcessing.sortedByTimestamp(coordinates)
        guard let last = ordered.last else { return }

        if context.coordinator.lastRenderedPointCount != ordered.count {
            if let existing = context.coordinator.polyline {
                mapView.removeOverlay(existing)
            }
            let line = MKPolyline(
                coordinates: ordered.map { CLLocationCoordinate2D(latitude: $0.latitude, longitude: $0.longitude) },
                count: ordered.count
            )
            mapView.addOverlay(line)
            context.coordinator.polyline = line
            context.coordinator.lastRenderedPointCount = ordered.count
        }

        let center = CLLocation(latitude: last.latitude, longitude: last.longitude)
        let maxDistance = ordered.reduce(0.0) { partial, point in
            let p = CLLocation(latitude: point.latitude, longitude: point.longitude)
            return max(partial, center.distance(from: p))
        }

        let spanMeters = max(120, min(650, maxDistance * 2.8))
        let region = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: last.latitude, longitude: last.longitude),
            latitudinalMeters: spanMeters,
            longitudinalMeters: spanMeters
        )

        let now = Date()
        if !context.coordinator.didSetInitialRegion || now.timeIntervalSince(context.coordinator.lastRegionUpdateAt) >= 1.0 {
            mapView.setRegion(region, animated: false)
            context.coordinator.didSetInitialRegion = true
            context.coordinator.lastRegionUpdateAt = now
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(onMapFullyRendered: onMapFullyRendered)
    }

    final class Coordinator: NSObject, MKMapViewDelegate {
        var didSetInitialRegion: Bool = false
        var didReportFullyRendered: Bool = false
        var lastRenderedPointCount: Int = 0
        var polyline: MKPolyline?
        var lastRegionUpdateAt: Date = .distantPast
        let onMapFullyRendered: () -> Void

        init(onMapFullyRendered: @escaping () -> Void) {
            self.onMapFullyRendered = onMapFullyRendered
        }

        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            guard let polyline = overlay as? MKPolyline else {
                return MKOverlayRenderer(overlay: overlay)
            }
            let renderer = MKPolylineRenderer(polyline: polyline)
            renderer.strokeColor = UIColor(AppTheme.mapPath).withAlphaComponent(0.9)
            renderer.lineWidth = 4
            renderer.lineJoin = .round
            renderer.lineCap = .round
            return renderer
        }

        func mapViewDidFinishRenderingMap(_ mapView: MKMapView, fullyRendered: Bool) {
            guard fullyRendered else { return }
            guard !didReportFullyRendered else { return }
            didReportFullyRendered = true
            onMapFullyRendered()
        }
    }
}
