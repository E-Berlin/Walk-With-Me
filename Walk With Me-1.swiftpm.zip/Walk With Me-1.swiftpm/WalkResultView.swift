import SwiftUI

struct WalkResultView: View {
    @EnvironmentObject private var session: WalkSessionViewModel
    @EnvironmentObject private var store: WalkStore

    let completeSave: (String) -> Void
    let walkAgain: () -> Void
    let backToHome: () -> Void

    @State private var selected: Color? = AppTheme.moodPalette.first
    @State private var shake: CGFloat = 0
    @State private var showWalkAgainSavePrompt: Bool = false

    private var hasArtwork: Bool {
        guard let points = session.currentWalk?.artworkPoints else { return false }
        return !points.isEmpty
    }

    private var isCurrentWalkSaved: Bool {
        session.lifecycle == .saved
    }

    var body: some View {
        VStack(alignment: .center, spacing: 16) {
            if hasArtwork {
                Text("How did the walk feel today?")
                    .font(.title3)
                    .fontWeight(.semibold)
                    .foregroundStyle(AppTheme.textPrimary)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }

            if let points = session.currentWalk?.artworkPoints, !points.isEmpty {
                ArtworkView(points: points, tint: selected ?? AppTheme.actionPrimary, lineWidth: 4)
                    .frame(maxWidth: .infinity)
                    .animation(.easeInOut(duration: 0.25), value: selected)
                    .transition(.opacity.combined(with: .scale(scale: 0.98)))
            } else {
                EmptyStateView(
                    title: "No artwork",
                    systemImage: "scribble",
                    message: "Try a slightly longer walk."
                )
                    .frame(maxWidth: .infinity)
                    .accessibilityLabel("No artwork")
            }

            if hasArtwork {
                VStack(alignment: .center, spacing: 12) {
                    Text("Pick one mood")
                        .font(.headline)
                        .foregroundStyle(AppTheme.textPrimary)

                    VStack(spacing: 12) {
                        ForEach(moodRows.indices, id: \.self) { rowIndex in
                            HStack(spacing: 14) {
                                ForEach(moodRows[rowIndex], id: \.self) { index in
                                    moodSwatchButton(index: index)
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .center)
                        }
                    }

                    Text("Selected mood: \(selectedMoodName)")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(AppTheme.textSecondary)
                        .frame(maxWidth: .infinity, alignment: .center)
                }
                .padding(12)
                .background(AppTheme.cardBackground, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .strokeBorder(AppTheme.surfaceStroke.opacity(0.45), lineWidth: 1)
                }
                .frame(maxWidth: .infinity, alignment: .center)
            }

            Spacer()

            if hasArtwork {
                VStack(spacing: 10) {
                    Button {
                        _ = saveCurrentWalk(openDetails: true)
                    } label: {
                        Label("Save", systemImage: "square.and.arrow.down")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(AppTheme.actionPrimary)
                    .frame(maxWidth: .infinity)
                    .accessibilityLabel("Save walk")
                    .modifier(ShakeEffect(animatableData: shake))

                    Button {
                        if isCurrentWalkSaved {
                            walkAgain()
                        } else {
                            showWalkAgainSavePrompt = true
                        }
                    } label: {
                        Label("Walk Again", systemImage: "arrow.clockwise.circle.fill")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                    }
                    .buttonStyle(.bordered)
                    .tint(AppTheme.actionSecondary)
                    .accessibilityLabel("Walk again")
                }
            } else {
                VStack(spacing: 10) {
                    Button {
                        walkAgain()
                    } label: {
                        Label("Walk Again", systemImage: "arrow.clockwise.circle.fill")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(AppTheme.actionPrimary)
                    .accessibilityLabel("Walk again")

                    Button {
                        backToHome()
                    } label: {
                        Label("Back to Home", systemImage: "house.fill")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                    }
                    .buttonStyle(.bordered)
                    .tint(AppTheme.actionSecondary)
                    .accessibilityLabel("Back to home")
                }
            }
        }
        .padding(20)
        .frame(maxWidth: .infinity)
        .background(AppTheme.pageBackground.ignoresSafeArea())
        .navigationTitle("Result")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarBackground(AppTheme.pageBackground, for: .navigationBar)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button {
                    backToHome()
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.headline.weight(.semibold))
                        .frame(minWidth: 44, minHeight: 44)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Back to Home")
            }
        }
        .confirmationDialog("Save this walk before walking again?", isPresented: $showWalkAgainSavePrompt, titleVisibility: .visible) {
            Button("Save and Walk Again") {
                if saveCurrentWalk(openDetails: false) {
                    walkAgain()
                }
            }
            Button("Walk Again Without Saving", role: .destructive) {
                walkAgain()
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("You can save first, or discard this result and start a new walk.")
        }
        .onAppear {
            if let hex = session.currentWalk?.moodColorHex, let c = Color(hex: hex) {
                selected = c
            } else if selected == nil {
                selected = AppTheme.moodPalette.first
            }
        }
    }

    private var moodRows: [[Int]] {
        let all = Array(AppTheme.moodPalette.indices)
        let rowSize = 4
        return stride(from: 0, to: all.count, by: rowSize).map { start in
            Array(all[start ..< min(start + rowSize, all.count)])
        }
    }

    @ViewBuilder
    private func moodSwatchButton(index: Int) -> some View {
        let color = AppTheme.moodPalette[index]
        let moodName = AppTheme.moodPaletteNames[index]
        let moodDisplayName = moodSingleWordName(index: index)
        let isSelected = selected?.toHex() == color.toHex()

        Button {
            selected = color
        } label: {
            VStack(spacing: 6) {
                Circle()
                    .fill(color)
                    .frame(width: 44, height: 44)
                    .overlay {
                        Circle()
                            .strokeBorder(isSelected ? AppTheme.textPrimary : .white.opacity(0.8), lineWidth: isSelected ? 3 : 1)
                    }
                    .shadow(color: AppTheme.textPrimary.opacity(isSelected ? 0.22 : 0.1), radius: isSelected ? 4 : 2, x: 0, y: 1)

                Text(moodDisplayName)
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(AppTheme.textSecondary)
                    .multilineTextAlignment(.center)
                    .lineLimit(1)
                    .frame(width: 70, height: 28, alignment: .top)
            }
            .frame(width: 70, height: 78, alignment: .top)
        }
        .buttonStyle(PressScaleButtonStyle())
        .accessibilityLabel("\(moodName) mood")
        .accessibilityValue(isSelected ? "Selected" : "Not selected")
        .accessibilityHint("Double tap to choose this mood")
    }

    private var selectedMoodName: String {
        guard let selected else { return "None" }
        guard let index = moodIndex(for: selected) else { return "Mood" }
        return AppTheme.moodPaletteNames[index]
    }

    private func moodIndex(for color: Color) -> Int? {
        guard let colorHex = color.toHex()?.lowercased() else { return nil }
        return AppTheme.moodPalette.firstIndex { paletteColor in
            paletteColor.toHex()?.lowercased() == colorHex
        }
    }

    private func moodSingleWordName(index: Int) -> String {
        let fullName = AppTheme.moodPaletteNames[index]
        return fullName.split(separator: " ").first.map(String.init) ?? fullName
    }

    @discardableResult
    private func saveCurrentWalk(openDetails: Bool) -> Bool {
        guard let selected else {
            withAnimation(.default) {
                shake += 1
            }
            return false
        }

        if let hex = selected.toHex() {
            session.setMoodColorHex(hex)
        }

        guard var walk = session.currentWalk else { return false }
        if walk.artworkName == nil {
            walk.artworkName = store.nextArtworkDefaultName()
        }
        store.upsert(walk)
        session.markSaved()
        if openDetails {
            completeSave(walk.id)
        }
        return true
    }
}

private struct ShakeEffect: GeometryEffect {
    var animatableData: CGFloat

    func effectValue(size: CGSize) -> ProjectionTransform {
        let translation = 8 * sin(animatableData * .pi * 6)
        return ProjectionTransform(CGAffineTransform(translationX: translation, y: 0))
    }
}
