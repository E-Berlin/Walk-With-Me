import Combine
import CoreLocation
import Foundation

@MainActor
final class WalkSessionViewModel: ObservableObject {
    private let minimumSegmentDistanceMeters: CLLocationDistance = 4

    @Published private(set) var lifecycle: WalkLifecycle = .idle
    @Published private(set) var currentWalk: WalkRecord?
    @Published private(set) var elapsed: TimeInterval = 0
    @Published private(set) var isPaused: Bool = false

    @Published var livePath: [WalkCoordinate] = []

    private var timer: Timer?
    private let locationManager: WalkLocationManager
    private var cancellables = Set<AnyCancellable>()
    private var pausedStartedAt: Date?
    private var accumulatedPausedDuration: TimeInterval = 0

    init(locationManager: WalkLocationManager) {
        self.locationManager = locationManager

        locationManager.$lastCoordinate
            .compactMap { $0 }
            .sink { [weak self] coord in
                self?.append(coordinate: coord)
            }
            .store(in: &cancellables)
    }

    func startWalk() {
        lifecycle = .recording
        let start = Date()
        currentWalk = WalkRecord(timestampStart: start, styleType: "default")
        livePath = []
        elapsed = 0
        isPaused = false
        pausedStartedAt = nil
        accumulatedPausedDuration = 0

        locationManager.startUpdates()

        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.updateElapsedTimeFromTimerTick()
            }
        }
    }

    func togglePause() {
        guard lifecycle == .recording else { return }

        if isPaused {
            if let pausedAt = pausedStartedAt {
                accumulatedPausedDuration += Date().timeIntervalSince(pausedAt)
            }
            pausedStartedAt = nil
            isPaused = false
            locationManager.startUpdates()
        } else {
            pausedStartedAt = Date()
            isPaused = true
            locationManager.stopUpdates()
        }
    }

    func endWalk() {
        guard lifecycle == .recording else { return }
        lifecycle = .processing

        timer?.invalidate()
        timer = nil

        locationManager.stopUpdates()

        guard var walk = currentWalk else {
            lifecycle = .idle
            return
        }
        let end = Date()
        if let pausedAt = pausedStartedAt {
            accumulatedPausedDuration += Date().timeIntervalSince(pausedAt)
        }
        isPaused = false
        pausedStartedAt = nil
        walk.timestampEnd = end
        walk.duration = max(0, end.timeIntervalSince(walk.timestampStart) - accumulatedPausedDuration)
        walk.pathCoordinates = livePath

        currentWalk = walk
    }

    func finishProcessing(artwork: [NormalizedPoint]) {
        guard lifecycle == .processing else { return }
        guard var walk = currentWalk else { return }
        walk.artworkPoints = artwork
        currentWalk = walk
        lifecycle = .moodSelection
    }

    func presentSimulatedResult(artwork: [NormalizedPoint], duration: TimeInterval) {
        let now = Date()
        currentWalk = WalkRecord(
            timestampStart: now.addingTimeInterval(-max(0, duration)),
            timestampEnd: now,
            duration: max(0, duration),
            pathCoordinates: [],
            moodColorHex: nil,
            artworkName: nil,
            styleType: "simulate",
            artworkPoints: artwork
        )
        lifecycle = .moodSelection
        elapsed = 0
        livePath = []
        isPaused = false
    }

    func setMoodColorHex(_ hex: String) {
        guard var walk = currentWalk else { return }
        walk.moodColorHex = hex
        currentWalk = walk
    }

    func markSaved() {
        lifecycle = .saved
    }

    func resetToIdle() {
        timer?.invalidate()
        timer = nil
        locationManager.stopUpdates()

        lifecycle = .idle
        currentWalk = nil
        elapsed = 0
        livePath = []
        isPaused = false
        pausedStartedAt = nil
        accumulatedPausedDuration = 0
    }

    private func append(coordinate: WalkCoordinate) {
        guard lifecycle == .recording else { return }
        guard !isPaused else { return }
        if let last = livePath.last {
            guard coordinate.timestamp > last.timestamp else { return }
            if distanceBetweenMeters(from: last, to: coordinate) < minimumSegmentDistanceMeters {
                return
            }
        }

        livePath.append(coordinate)
    }

    private func distanceBetweenMeters(from: WalkCoordinate, to: WalkCoordinate) -> CLLocationDistance {
        let a = CLLocation(latitude: from.latitude, longitude: from.longitude)
        let b = CLLocation(latitude: to.latitude, longitude: to.longitude)
        return a.distance(from: b)
    }

    private func updateElapsedTimeFromTimerTick() {
        guard let start = currentWalk?.timestampStart else { return }
        let pausedNow = pausedStartedAt.map { Date().timeIntervalSince($0) } ?? 0
        elapsed = max(0, Date().timeIntervalSince(start) - accumulatedPausedDuration - pausedNow)
    }
}
