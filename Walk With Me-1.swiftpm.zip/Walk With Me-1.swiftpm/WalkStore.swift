import Foundation

@MainActor
final class WalkStore: ObservableObject {
    @Published private(set) var walks: [WalkRecord] = []

    let artworkNameCharacterLimit: Int = 24

    private let fileURL: URL

    init(filename: String = "walks.json") {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        self.fileURL = docs.appendingPathComponent(filename)
        load()
        ensureFixedSampleWalks()
    }

    func load() {
        do {
            guard FileManager.default.fileExists(atPath: fileURL.path) else {
                walks = []
                return
            }
            let data = try Data(contentsOf: fileURL)
            let decoded = try JSONDecoder().decode([WalkRecord].self, from: data)
            walks = decoded.sorted(by: { $0.timestampStart > $1.timestampStart })
        } catch {
            walks = []
        }
    }

    func upsert(_ walk: WalkRecord) {
        if let idx = walks.firstIndex(where: { $0.id == walk.id }) {
            walks[idx] = walk
        } else {
            walks.insert(walk, at: 0)
        }
        persist()
    }

    func walk(withID id: String) -> WalkRecord? {
        walks.first(where: { $0.id == id })
    }

    func displayName(for walk: WalkRecord) -> String {
        if let raw = walk.artworkName,
           let trimmed = normalizedArtworkName(from: raw),
           !trimmed.isEmpty {
            return trimmed
        }

        let ordered = walks.sorted(by: { $0.timestampStart < $1.timestampStart })
        if let idx = ordered.firstIndex(where: { $0.id == walk.id }) {
            return "New Artwork \(idx + 1)"
        }
        return nextArtworkDefaultName()
    }

    func nextArtworkDefaultName() -> String {
        let next = (walks.compactMap { extractArtworkIndex(from: $0.artworkName) }.max() ?? 0) + 1
        return "New Artwork \(next)"
    }

    func rename(walkID: String, to newName: String) {
        guard let normalized = normalizedArtworkName(from: newName) else { return }
        guard let idx = walks.firstIndex(where: { $0.id == walkID }) else { return }
        walks[idx].artworkName = normalized
        persist()
    }

    func delete(walkID: String) {
        let originalCount = walks.count
        walks.removeAll(where: { $0.id == walkID })
        guard walks.count != originalCount else { return }
        persist()
    }

    func deleteAll() {
        walks = []
        persist()
    }

    func normalizedArtworkName(from input: String) -> String? {
        let trimmed = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        return String(trimmed.prefix(artworkNameCharacterLimit))
    }

    private func persist() {
        do {
            let data = try JSONEncoder().encode(walks)
            try data.write(to: fileURL, options: [.atomic])
        } catch {
            // Intentionally ignore for MVP (offline, best-effort)
        }
    }

    private func ensureFixedSampleWalks() {
        let calendar = Calendar.current
        let colors = ["#3B82F6", "#10B981", "#F97316"]
        let targets: [(year: Int, month: Int, day: Int)] = [
            (2025, 10, 1),
            (2025, 12, 20),
            (2026, 1, 1)
        ]

        var changed = false

        for (index, target) in targets.enumerated() {
            var components = DateComponents()
            components.year = target.year
            components.month = target.month
            components.day = target.day
            components.hour = 12
            components.minute = 0

            guard let start = calendar.date(from: components) else { continue }

            let alreadyExists = walks.contains { existing in
                calendar.isDate(existing.timestampStart, inSameDayAs: start)
            }
            if alreadyExists { continue }

            let end = start.addingTimeInterval(18 * 60)
            let artwork = Self.makeSampleArtwork(seed: Double(index + 1))

            let sample = WalkRecord(
                timestampStart: start,
                timestampEnd: end,
                duration: end.timeIntervalSince(start),
                pathCoordinates: [],
                moodColorHex: colors[index % colors.count],
                styleType: "default",
                artworkPoints: artwork
            )

            walks.append(sample)
            changed = true
        }

        guard changed else { return }
        walks.sort(by: { $0.timestampStart > $1.timestampStart })
        persist()
    }

    private static func makeSampleArtwork(seed: Double) -> [NormalizedPoint] {
        stride(from: 0.0, through: 1.0, by: 0.06).map { t in
            let wave = 0.22 * sin((t * 2 * .pi * seed) + seed)
            let drift = 0.08 * cos((t * 3 * .pi) + seed)
            let y = min(0.9, max(0.1, 0.5 + wave + drift))
            return NormalizedPoint(x: t, y: y)
        }
    }

    private func extractArtworkIndex(from name: String?) -> Int? {
        guard let name else { return nil }
        let pattern = #"^New Artwork\s+(\d+)$"#
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return nil }
        let range = NSRange(location: 0, length: name.utf16.count)
        guard let match = regex.firstMatch(in: name, options: [], range: range),
              let numRange = Range(match.range(at: 1), in: name)
        else {
            return nil
        }
        return Int(name[numRange])
    }
}
